<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-11 15:40:48 --> 404 Page Not Found: Robotstxt/index
