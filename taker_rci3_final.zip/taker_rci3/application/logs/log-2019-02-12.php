<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-12 06:33:13 --> 404 Page Not Found: Robotstxt/index
