<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-21 02:12:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-21 02:13:00 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-21 03:16:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-05-21 03:41:24 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-21 05:01:55 --> 404 Page Not Found: Taker/index
ERROR - 2019-05-21 05:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-21 22:46:46 --> 404 Page Not Found: Taker/index
