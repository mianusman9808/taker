<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-02 01:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-02 11:24:31 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-03-02 15:39:45 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-03-02 23:39:27 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2022-03-02 23:39:27 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2022-03-02 23:39:28 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-03-02 23:39:28 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-03-02 23:39:28 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-03-02 23:39:28 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-03-02 23:39:28 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-03-02 23:39:28 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-03-02 23:39:29 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2022-03-02 23:39:29 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-03-02 23:39:29 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-03-02 23:39:29 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-03-02 23:39:29 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-03-02 23:39:29 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-03-02 23:39:29 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-03-02 23:39:30 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-03-02 23:39:30 --> 404 Page Not Found: Sito/wp-includes
