<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-11 03:43:30 --> 404 Page Not Found: Taker/index
ERROR - 2019-06-11 05:14:36 --> 404 Page Not Found: Taker/index.php
ERROR - 2019-06-11 07:32:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-11 11:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-11 22:36:45 --> 404 Page Not Found: Robotstxt/index
