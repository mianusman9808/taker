<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-03 08:55:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-03 22:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-03 23:22:21 --> 404 Page Not Found: Robotstxt/index
