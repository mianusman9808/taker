<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-09 11:07:59 --> 404 Page Not Found: Wp-loginphp/index
