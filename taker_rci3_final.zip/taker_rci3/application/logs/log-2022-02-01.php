<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-01 04:52:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-01 15:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-01 18:22:54 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-02-01 18:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-01 19:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-01 20:14:10 --> 404 Page Not Found: Vendor/phpunit
