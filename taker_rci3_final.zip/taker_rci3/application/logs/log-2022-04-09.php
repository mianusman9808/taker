<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-09 07:06:14 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-04-09 12:37:55 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-04-09 14:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-04-09 23:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-04-09 23:57:57 --> 404 Page Not Found: Taker/assets
