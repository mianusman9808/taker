<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-09 05:05:17 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2021-10-09 21:04:05 --> 404 Page Not Found: Robotstxt/index
