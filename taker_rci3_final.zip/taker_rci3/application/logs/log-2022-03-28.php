<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-28 08:25:38 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /var/www/www.taker.com.ar/html/taker_rci3/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2022-03-28 08:25:38 --> Unable to connect to the database
ERROR - 2022-03-28 08:25:38 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /var/www/www.taker.com.ar/html/taker_rci3/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2022-03-28 08:25:38 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /var/www/www.taker.com.ar/html/taker_rci3/system/libraries/Session/Session.php 141
