<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-17 02:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-17 03:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-17 03:33:17 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-17 07:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-17 18:52:50 --> 404 Page Not Found: Js/html5.js
ERROR - 2019-05-17 19:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-17 23:52:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-17 23:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-17 23:56:07 --> 404 Page Not Found: Robotstxt/index
