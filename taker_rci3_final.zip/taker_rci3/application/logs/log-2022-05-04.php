<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-04 02:49:00 --> 404 Page Not Found: Taker/index
ERROR - 2022-05-04 14:44:46 --> 404 Page Not Found: Wp-admin/css
ERROR - 2022-05-04 14:44:57 --> 404 Page Not Found: Well-known/index
ERROR - 2022-05-04 14:45:04 --> 404 Page Not Found: Sites/default
ERROR - 2022-05-04 14:45:18 --> 404 Page Not Found: Admin/controller
ERROR - 2022-05-04 14:45:39 --> 404 Page Not Found: Uploads/index
ERROR - 2022-05-04 16:57:54 --> 404 Page Not Found: Wp-loginphp/index
