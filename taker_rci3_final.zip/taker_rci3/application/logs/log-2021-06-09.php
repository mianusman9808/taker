<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-09 11:38:50 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2021-06-09 11:38:53 --> 404 Page Not Found: Wordpress/wp-login.php
ERROR - 2021-06-09 11:38:56 --> 404 Page Not Found: Blog/wp-login.php
ERROR - 2021-06-09 11:38:58 --> 404 Page Not Found: Wp/wp-login.php
