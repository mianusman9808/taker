<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-27 07:36:30 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2021-05-27 07:36:31 --> 404 Page Not Found: Wordpress/wp-login.php
ERROR - 2021-05-27 07:36:32 --> 404 Page Not Found: Blog/wp-login.php
ERROR - 2021-05-27 07:36:33 --> 404 Page Not Found: Wp/wp-login.php
