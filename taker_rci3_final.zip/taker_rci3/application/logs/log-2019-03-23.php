<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-23 00:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-23 19:12:26 --> 404 Page Not Found: Libraries/libraries.php
ERROR - 2019-03-23 19:12:27 --> 404 Page Not Found: Libraries/libraries.php
ERROR - 2019-03-23 21:29:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-23 23:30:59 --> 404 Page Not Found: Robotstxt/index
