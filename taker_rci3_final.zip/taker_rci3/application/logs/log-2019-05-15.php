<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-15 00:48:01 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-15 00:58:08 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-15 11:27:09 --> 404 Page Not Found: Js/html5.js
