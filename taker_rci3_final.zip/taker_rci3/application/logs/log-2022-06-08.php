<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-08 10:21:54 --> 404 Page Not Found: Robotstxt/index
