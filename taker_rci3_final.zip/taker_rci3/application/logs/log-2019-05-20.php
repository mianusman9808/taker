<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-20 01:38:58 --> 404 Page Not Found: Js/html5.js
ERROR - 2019-05-20 01:38:59 --> 404 Page Not Found: Js/respond.min.js
ERROR - 2019-05-20 01:39:07 --> 404 Page Not Found: Js/html5.js
ERROR - 2019-05-20 01:39:09 --> 404 Page Not Found: Js/respond.min.js
ERROR - 2019-05-20 01:52:03 --> 404 Page Not Found: Js/respond.min.js
ERROR - 2019-05-20 01:52:05 --> 404 Page Not Found: Js/respond.min.js
ERROR - 2019-05-20 01:52:17 --> 404 Page Not Found: Js/html5.js
ERROR - 2019-05-20 01:52:19 --> 404 Page Not Found: Js/html5.js
ERROR - 2019-05-20 04:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-20 04:58:06 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-20 18:11:46 --> 404 Page Not Found: Js/html5.js
ERROR - 2019-05-20 22:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-20 22:54:50 --> 404 Page Not Found: Robotstxt/index
