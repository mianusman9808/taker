<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-27 14:12:20 --> 404 Page Not Found: Wp-plainphp/index
ERROR - 2022-05-27 14:12:44 --> 404 Page Not Found: Dktlrtnzphp/index
ERROR - 2022-05-27 15:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-05-27 17:25:54 --> 404 Page Not Found: Wp-loginphp/index
