<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-24 05:05:52 --> 404 Page Not Found: Taker/index.php
ERROR - 2019-05-24 06:39:19 --> 404 Page Not Found: Robotstxt/index
