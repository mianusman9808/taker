<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-09 13:16:53 --> 404 Page Not Found: Robotstxt/index
