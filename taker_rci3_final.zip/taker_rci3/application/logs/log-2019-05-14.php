<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-14 17:28:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-14 23:45:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-14 23:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-14 23:57:52 --> 404 Page Not Found: Taker/assets
