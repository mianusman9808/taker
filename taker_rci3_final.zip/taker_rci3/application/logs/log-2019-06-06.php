<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-06 23:55:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-06 23:56:40 --> 404 Page Not Found: Robotstxt/index
