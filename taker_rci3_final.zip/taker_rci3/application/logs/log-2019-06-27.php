<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-27 09:31:14 --> 404 Page Not Found: Taker/index
ERROR - 2019-06-27 13:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-27 13:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-27 20:43:50 --> 404 Page Not Found: Taker/index
