<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-30 04:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-30 18:15:10 --> Severity: Notice --> Array to string conversion /var/www/www.taker.com.ar/html/taker_rci3/application/nusoap/nusoap.php 3125
ERROR - 2019-03-30 18:22:54 --> Severity: Notice --> Array to string conversion /var/www/www.taker.com.ar/html/taker_rci3/application/nusoap/nusoap.php 3125
ERROR - 2019-03-30 18:58:05 --> Severity: Notice --> Array to string conversion /var/www/www.taker.com.ar/html/taker_rci3/application/nusoap/nusoap.php 3125
ERROR - 2019-03-30 19:33:45 --> Severity: Notice --> Array to string conversion /var/www/www.taker.com.ar/html/taker_rci3/application/nusoap/nusoap.php 3125
