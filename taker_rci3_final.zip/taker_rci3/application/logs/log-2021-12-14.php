<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-14 12:33:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-14 23:07:39 --> 404 Page Not Found: Old-indexphp/index
