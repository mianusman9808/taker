<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-08 05:58:00 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-12-08 12:26:11 --> 404 Page Not Found: Robotstxt/index
