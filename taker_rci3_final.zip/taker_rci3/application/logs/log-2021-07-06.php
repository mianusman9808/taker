<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-06 00:54:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-06 15:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-06 21:29:20 --> 404 Page Not Found: Robotstxt/index
