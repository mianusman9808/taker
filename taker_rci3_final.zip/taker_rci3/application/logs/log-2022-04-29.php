<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-29 17:38:52 --> 404 Page Not Found: Wp-admin/css
ERROR - 2022-04-29 17:39:02 --> 404 Page Not Found: Well-known/index
ERROR - 2022-04-29 17:39:13 --> 404 Page Not Found: Sites/default
ERROR - 2022-04-29 17:39:26 --> 404 Page Not Found: Admin/controller
ERROR - 2022-04-29 17:39:37 --> 404 Page Not Found: Uploads/index
ERROR - 2022-04-29 21:56:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-04-29 22:28:58 --> 404 Page Not Found: Wp-loginphp/index
