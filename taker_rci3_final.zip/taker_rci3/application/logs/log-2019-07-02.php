<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-02 14:57:39 --> 404 Page Not Found: Taker/index.php
ERROR - 2019-07-02 20:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-02 22:52:58 --> 404 Page Not Found: Robotstxt/index
