<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-16 03:25:16 --> 404 Page Not Found: Robotstxt/index
