<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-20 01:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-20 03:56:56 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-11-20 03:57:18 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-11-20 11:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-20 19:15:07 --> 404 Page Not Found: Robotstxt/index
