<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-07 11:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-07 14:00:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-07 22:35:00 --> 404 Page Not Found: Robotstxt/index
