<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-06 01:43:05 --> 404 Page Not Found: Js/respond.min.js
ERROR - 2021-11-06 07:07:47 --> 404 Page Not Found: Cgi-bin/mt
ERROR - 2021-11-06 12:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-06 19:07:46 --> 404 Page Not Found: Robotstxt/index
