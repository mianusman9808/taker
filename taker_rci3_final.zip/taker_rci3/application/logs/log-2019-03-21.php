<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-21 03:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-21 13:17:03 --> 404 Page Not Found: Libraries/libraries.php
ERROR - 2019-03-21 13:17:05 --> 404 Page Not Found: Libraries/libraries.php
