<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-11 22:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-11 22:56:07 --> 404 Page Not Found: Robotstxt/index
