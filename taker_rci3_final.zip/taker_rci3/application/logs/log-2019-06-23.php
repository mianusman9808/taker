<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-23 19:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-23 23:12:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-23 23:17:21 --> 404 Page Not Found: Robotstxt/index
