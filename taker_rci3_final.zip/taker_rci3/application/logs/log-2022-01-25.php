<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-25 06:23:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-25 15:40:48 --> 404 Page Not Found: Robotstxt/index
