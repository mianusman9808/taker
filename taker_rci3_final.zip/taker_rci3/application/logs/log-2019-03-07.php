<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-07 23:48:14 --> 404 Page Not Found: Robotstxt/index
