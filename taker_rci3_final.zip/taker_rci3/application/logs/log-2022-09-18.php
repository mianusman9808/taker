<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-18 19:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-09-18 19:14:31 --> 404 Page Not Found: Taker/assets
