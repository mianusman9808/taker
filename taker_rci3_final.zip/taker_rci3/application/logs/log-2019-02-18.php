<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-18 00:26:52 --> 404 Page Not Found: Robotstxt/index
