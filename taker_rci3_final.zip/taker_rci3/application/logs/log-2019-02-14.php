<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-14 05:51:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-14 09:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-14 10:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-14 23:13:04 --> 404 Page Not Found: Robotstxt/index
