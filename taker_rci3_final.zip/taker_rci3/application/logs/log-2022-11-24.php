<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-24 17:44:05 --> Severity: Warning --> include_once(../taker/inc/header.php): failed to open stream: No such file or directory C:\xampp\htdocs\taker_rci3\taker_rci3\application\views\acceso\index.php 3
ERROR - 2022-11-24 17:44:05 --> Severity: Warning --> include_once(): Failed opening '../taker/inc/header.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\taker_rci3\taker_rci3\application\views\acceso\index.php 3
ERROR - 2022-11-24 17:44:05 --> Severity: Notice --> Undefined variable: productos C:\xampp\htdocs\taker_rci3\taker_rci3\application\views\acceso\index.php 4
ERROR - 2022-11-24 17:44:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\taker_rci3\taker_rci3\application\views\acceso\index.php 4
ERROR - 2022-11-24 17:44:05 --> Severity: Warning --> include_once(../taker/inc/template.php): failed to open stream: No such file or directory C:\xampp\htdocs\taker_rci3\taker_rci3\application\views\acceso\index.php 6
ERROR - 2022-11-24 17:44:05 --> Severity: Warning --> include_once(): Failed opening '../taker/inc/template.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\taker_rci3\taker_rci3\application\views\acceso\index.php 6
ERROR - 2022-11-24 17:44:05 --> Severity: Warning --> include_once(../taker/inc/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\taker_rci3\taker_rci3\application\views\acceso\index.php 7
ERROR - 2022-11-24 17:44:05 --> Severity: Warning --> include_once(): Failed opening '../taker/inc/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\taker_rci3\taker_rci3\application\views\acceso\index.php 7
ERROR - 2022-11-24 17:51:55 --> Severity: Warning --> include_once(../taker/inc/header.php): failed to open stream: No such file or directory C:\xampp\htdocs\taker_rci3\taker_rci3\application\views\acceso\index.php 3
ERROR - 2022-11-24 17:51:55 --> Severity: Warning --> include_once(): Failed opening '../taker/inc/header.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\taker_rci3\taker_rci3\application\views\acceso\index.php 3
ERROR - 2022-11-24 17:51:55 --> Severity: Notice --> Undefined variable: productos C:\xampp\htdocs\taker_rci3\taker_rci3\application\views\acceso\index.php 4
ERROR - 2022-11-24 17:51:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\taker_rci3\taker_rci3\application\views\acceso\index.php 4
ERROR - 2022-11-24 17:51:55 --> Severity: Warning --> include_once(../taker/inc/template.php): failed to open stream: No such file or directory C:\xampp\htdocs\taker_rci3\taker_rci3\application\views\acceso\index.php 6
ERROR - 2022-11-24 17:51:55 --> Severity: Warning --> include_once(): Failed opening '../taker/inc/template.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\taker_rci3\taker_rci3\application\views\acceso\index.php 6
ERROR - 2022-11-24 17:51:55 --> Severity: Warning --> include_once(../taker/inc/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\taker_rci3\taker_rci3\application\views\acceso\index.php 7
ERROR - 2022-11-24 17:51:55 --> Severity: Warning --> include_once(): Failed opening '../taker/inc/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\taker_rci3\taker_rci3\application\views\acceso\index.php 7
ERROR - 2022-11-24 17:52:43 --> Severity: Notice --> Undefined variable: contacto C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:52:43 --> Severity: Warning --> include_once(C:\xampp\php\pear): failed to open stream: Permission denied C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:52:43 --> Severity: Warning --> include_once(): Failed opening '' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:53:34 --> Severity: Notice --> Undefined variable: contacto C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:53:34 --> Severity: Warning --> include_once(C:\xampp\php\pear): failed to open stream: Permission denied C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:53:34 --> Severity: Warning --> include_once(): Failed opening '' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:53:45 --> Severity: Notice --> Undefined variable: contacto C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:53:45 --> Severity: Warning --> include_once(C:\xampp\php\pear): failed to open stream: Permission denied C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:53:45 --> Severity: Warning --> include_once(): Failed opening '' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:54:46 --> Severity: Notice --> Undefined variable: contacto C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:54:46 --> Severity: Warning --> include_once(C:\xampp\php\pear): failed to open stream: Permission denied C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:54:46 --> Severity: Warning --> include_once(): Failed opening '' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:54:48 --> Severity: Notice --> Undefined variable: contacto C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:54:48 --> Severity: Warning --> include_once(C:\xampp\php\pear): failed to open stream: Permission denied C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:54:48 --> Severity: Warning --> include_once(): Failed opening '' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:58:57 --> Severity: Notice --> Undefined variable: contacto C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:58:57 --> Severity: Warning --> include_once(C:\xampp\php\pear): failed to open stream: Permission denied C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 17:58:57 --> Severity: Warning --> include_once(): Failed opening '' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 18:12:08 --> Severity: Notice --> Undefined variable: contacto C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 18:12:08 --> Severity: Warning --> include_once(C:\xampp\php\pear): failed to open stream: Permission denied C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-24 18:12:08 --> Severity: Warning --> include_once(): Failed opening '' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
