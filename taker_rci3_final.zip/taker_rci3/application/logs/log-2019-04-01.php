<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-01 08:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-01 21:08:05 --> 404 Page Not Found: Robotstxt/index
