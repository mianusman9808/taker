<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-04 04:16:12 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-01-04 09:49:14 --> 404 Page Not Found: ALFA_DATA/alfacgiapi
ERROR - 2022-01-04 09:49:45 --> 404 Page Not Found: Alfacgiapi/perl.alfa
ERROR - 2022-01-04 21:19:43 --> 404 Page Not Found: Faviconico/index
