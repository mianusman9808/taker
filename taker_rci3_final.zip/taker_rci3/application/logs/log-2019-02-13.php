<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-13 02:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-13 20:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-13 20:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-13 23:07:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-13 23:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-13 23:07:26 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2019-02-13 23:07:27 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2019-02-13 23:31:18 --> 404 Page Not Found: Robotstxt/index
