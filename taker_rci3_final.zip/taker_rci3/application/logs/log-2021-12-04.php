<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-04 15:45:32 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2021-12-04 16:31:48 --> 404 Page Not Found: Robotstxt/index
