<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-17 19:52:44 --> 404 Page Not Found: Robotstxt/index
