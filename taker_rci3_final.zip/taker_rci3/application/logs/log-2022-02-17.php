<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-17 04:42:35 --> 404 Page Not Found: Robotstxt/index
