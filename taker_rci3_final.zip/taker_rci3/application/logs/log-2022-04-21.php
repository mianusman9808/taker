<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-21 09:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-04-21 09:52:15 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2022-04-21 19:20:18 --> 404 Page Not Found: Xleetphp/index
ERROR - 2022-04-21 19:20:18 --> 404 Page Not Found: Takeoutphp/index
ERROR - 2022-04-21 19:20:18 --> 404 Page Not Found: Xleet-shellphp/index
ERROR - 2022-04-21 19:20:18 --> 404 Page Not Found: Xletphp/index
ERROR - 2022-04-21 19:20:18 --> 404 Page Not Found: Adminphp/index
ERROR - 2022-04-21 19:20:19 --> 404 Page Not Found: Sh3llxphp/index
ERROR - 2022-04-21 19:20:21 --> 404 Page Not Found: Jindexphp/index
