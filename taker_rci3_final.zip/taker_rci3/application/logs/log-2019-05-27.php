<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-27 06:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-27 06:00:27 --> 404 Page Not Found: Taker/index.php
ERROR - 2019-05-27 07:40:07 --> 404 Page Not Found: Js/html5.js
ERROR - 2019-05-27 07:40:09 --> 404 Page Not Found: Js/respond.min.js
ERROR - 2019-05-27 14:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-27 23:33:41 --> 404 Page Not Found: Robotstxt/index
