<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-26 09:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-26 23:25:19 --> 404 Page Not Found: Robotstxt/index
