<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-13 12:40:24 --> Non-existent class: Datagrid
ERROR - 2019-04-13 12:55:36 --> Severity: Warning --> include(/web/paguiar/taker_rci3/system/datagrid/models/datagrid_model.php): failed to open stream: No such file or directory /web/paguiar/taker_rci3/application/models/Datagrid_model.php 3
ERROR - 2019-04-13 12:55:36 --> Severity: Warning --> include(): Failed opening '/web/paguiar/taker_rci3/system/datagrid/models/datagrid_model.php' for inclusion (include_path='.:/usr/share/php') /web/paguiar/taker_rci3/application/models/Datagrid_model.php 3
ERROR - 2019-04-13 12:55:36 --> Severity: error --> Exception: /web/paguiar/taker_rci3/application/models/Datagrid_model.php exists, but doesn't declare class Datagrid_model /web/paguiar/taker_rci3/system/core/Loader.php 336
