<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-07 05:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-09-07 19:34:11 --> 404 Page Not Found: Wp/index
ERROR - 2022-09-07 19:34:12 --> 404 Page Not Found: Wordpress/index
ERROR - 2022-09-07 19:34:14 --> 404 Page Not Found: Old/index
ERROR - 2022-09-07 19:34:15 --> 404 Page Not Found: Blog/index
ERROR - 2022-09-07 19:34:17 --> 404 Page Not Found: Demo/index
ERROR - 2022-09-07 19:34:19 --> 404 Page Not Found: Backup/index
ERROR - 2022-09-07 19:34:20 --> 404 Page Not Found: New/index
ERROR - 2022-09-07 19:34:21 --> 404 Page Not Found: Shop/index
ERROR - 2022-09-07 19:34:23 --> 404 Page Not Found: Test/index
ERROR - 2022-09-07 20:42:47 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-09-07 22:31:55 --> 404 Page Not Found: Robotstxt/index
