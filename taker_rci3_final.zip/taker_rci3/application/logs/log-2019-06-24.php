<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-24 22:59:13 --> 404 Page Not Found: Robotstxt/index
