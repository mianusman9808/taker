<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-15 08:42:51 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2021-02-15 16:42:17 --> 404 Page Not Found: Robotstxt/index
