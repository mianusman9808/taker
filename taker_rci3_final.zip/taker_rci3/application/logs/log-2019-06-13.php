<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-13 00:07:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-13 00:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-13 01:52:37 --> 404 Page Not Found: Taker/index.php
ERROR - 2019-06-13 09:41:42 --> 404 Page Not Found: Robotstxt/index
