<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-26 22:39:56 --> 404 Page Not Found: Robotstxt/index
