<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-07 04:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-07 23:05:54 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2019-12-07 23:57:23 --> 404 Page Not Found: Robotstxt/index
