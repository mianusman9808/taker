<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-15 10:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-08-15 19:12:50 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-08-15 22:06:16 --> 404 Page Not Found: Robotstxt/index
