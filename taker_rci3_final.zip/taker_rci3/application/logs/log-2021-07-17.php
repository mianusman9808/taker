<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-17 05:44:57 --> 404 Page Not Found: Robotstxt/index
