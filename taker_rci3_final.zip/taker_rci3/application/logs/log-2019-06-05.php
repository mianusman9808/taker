<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-05 17:21:42 --> 404 Page Not Found: Robotstxt/index
