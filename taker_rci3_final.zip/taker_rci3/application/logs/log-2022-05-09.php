<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-09 07:21:47 --> 404 Page Not Found: Wp-plainphp/index
ERROR - 2022-05-09 07:22:09 --> 404 Page Not Found: Kcxjdhplphp/index
ERROR - 2022-05-09 18:55:22 --> 404 Page Not Found: Robotstxt/index
