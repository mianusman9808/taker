<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-10 01:21:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-10 11:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-10 18:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-10 23:54:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-10 23:54:38 --> 404 Page Not Found: Robotstxt/index
