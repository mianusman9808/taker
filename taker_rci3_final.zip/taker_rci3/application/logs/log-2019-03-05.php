<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-05 01:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-05 12:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-05 17:15:49 --> 404 Page Not Found: Robotstxt/index
