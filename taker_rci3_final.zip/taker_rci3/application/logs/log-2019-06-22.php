<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-22 13:08:42 --> 404 Page Not Found: Taker/index
ERROR - 2019-06-22 16:25:17 --> 404 Page Not Found: Libraries/libraries.php
ERROR - 2019-06-22 16:25:20 --> 404 Page Not Found: Libraries/libraries.php
