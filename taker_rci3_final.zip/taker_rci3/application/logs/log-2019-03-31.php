<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-31 14:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-31 23:10:24 --> 404 Page Not Found: Robotstxt/index
