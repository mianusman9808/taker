<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-27 00:11:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-27 06:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-27 12:11:14 --> 404 Page Not Found: Usuario/index
ERROR - 2019-03-27 13:11:27 --> 404 Page Not Found: Robotstxt/index
