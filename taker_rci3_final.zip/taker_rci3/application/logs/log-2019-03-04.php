<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-04 05:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-04 17:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-04 17:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-04 20:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-04 20:58:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-04 20:58:42 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2019-03-04 20:58:52 --> 404 Page Not Found: Sitemapxml/index
