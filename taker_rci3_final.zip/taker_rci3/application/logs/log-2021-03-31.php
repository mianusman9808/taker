<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-31 05:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-31 10:43:46 --> 404 Page Not Found: Wp-loginphp/index
