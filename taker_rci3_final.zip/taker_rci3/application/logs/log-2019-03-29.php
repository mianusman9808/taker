<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-29 06:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-29 11:03:40 --> 404 Page Not Found: Libraries/libraries.php
ERROR - 2019-03-29 11:03:42 --> 404 Page Not Found: Libraries/libraries.php
ERROR - 2019-03-29 15:35:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-29 17:48:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-29 17:48:32 --> 404 Page Not Found: Robotstxt/index
