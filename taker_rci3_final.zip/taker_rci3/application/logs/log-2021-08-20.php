<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-20 06:47:00 --> 404 Page Not Found: Robotstxt/index
