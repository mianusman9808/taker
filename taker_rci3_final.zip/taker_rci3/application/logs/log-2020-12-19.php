<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-19 04:39:09 --> 404 Page Not Found: Wp-content/plugins
