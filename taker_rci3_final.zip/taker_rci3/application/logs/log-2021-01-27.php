<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-27 02:18:48 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2021-01-27 04:32:29 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2021-01-27 21:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-27 21:28:15 --> 404 Page Not Found: Sitemaptxt/index
