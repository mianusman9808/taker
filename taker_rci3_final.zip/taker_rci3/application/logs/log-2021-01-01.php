<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-01 17:19:51 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-01-01 18:25:37 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2021-01-01 19:09:12 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2021-01-01 19:27:54 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-01-01 21:42:16 --> 404 Page Not Found: Emergencyphp/index
ERROR - 2021-01-01 23:24:26 --> 404 Page Not Found: Atomxml/index
