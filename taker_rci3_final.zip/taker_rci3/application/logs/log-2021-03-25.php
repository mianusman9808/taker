<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-25 11:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-25 13:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-25 22:47:35 --> 404 Page Not Found: Wp-content/db-cache.php
ERROR - 2021-03-25 22:48:23 --> 404 Page Not Found: Wp-content/db-cache.php
