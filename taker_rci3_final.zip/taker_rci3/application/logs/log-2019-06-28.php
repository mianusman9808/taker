<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-28 19:43:57 --> 404 Page Not Found: Taker/assets
ERROR - 2019-06-28 19:43:58 --> 404 Page Not Found: Taker/assets
ERROR - 2019-06-28 19:44:00 --> 404 Page Not Found: Taker/assets
ERROR - 2019-06-28 19:44:02 --> 404 Page Not Found: Taker/assets
ERROR - 2019-06-28 19:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-28 23:06:33 --> 404 Page Not Found: Robotstxt/index
