<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-21 00:34:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-21 01:14:11 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-05-21 17:01:34 --> 404 Page Not Found: Acceso/js
ERROR - 2022-05-21 17:01:34 --> 404 Page Not Found: Acceso/js
ERROR - 2022-05-21 17:02:47 --> 404 Page Not Found: Acceso/js
ERROR - 2022-05-21 17:02:47 --> 404 Page Not Found: Acceso/js
ERROR - 2022-05-21 17:03:30 --> 404 Page Not Found: Acceso/js
ERROR - 2022-05-21 17:03:30 --> 404 Page Not Found: Acceso/js
ERROR - 2022-05-21 17:03:54 --> 404 Page Not Found: Acceso/js
ERROR - 2022-05-21 17:03:54 --> 404 Page Not Found: Acceso/js
ERROR - 2022-05-21 17:04:50 --> 404 Page Not Found: Acceso/js
ERROR - 2022-05-21 17:04:50 --> 404 Page Not Found: Acceso/js
ERROR - 2022-05-21 17:05:59 --> 404 Page Not Found: Acceso/js
ERROR - 2022-05-21 17:05:59 --> 404 Page Not Found: Acceso/js
ERROR - 2022-05-21 17:06:16 --> 404 Page Not Found: Acceso/js
ERROR - 2022-05-21 17:06:16 --> 404 Page Not Found: Acceso/js
