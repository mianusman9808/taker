<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-12 22:40:50 --> 404 Page Not Found: Robotstxt/index
