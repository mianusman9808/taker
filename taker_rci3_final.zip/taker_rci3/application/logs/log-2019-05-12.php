<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-12 17:09:54 --> 404 Page Not Found: Js/html5.js
ERROR - 2019-05-12 17:09:55 --> 404 Page Not Found: Js/respond.min.js
