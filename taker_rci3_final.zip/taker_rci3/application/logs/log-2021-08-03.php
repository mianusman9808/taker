<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-03 10:51:35 --> 404 Page Not Found: Robotstxt/index
