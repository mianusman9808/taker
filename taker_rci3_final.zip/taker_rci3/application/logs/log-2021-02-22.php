<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-22 00:19:04 --> 404 Page Not Found: Git/HEAD
ERROR - 2021-02-22 04:07:29 --> 404 Page Not Found: Git/HEAD
ERROR - 2021-02-22 11:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-22 12:48:53 --> 404 Page Not Found: Git/HEAD
ERROR - 2021-02-22 14:23:52 --> 404 Page Not Found: Git/HEAD
ERROR - 2021-02-22 16:42:38 --> 404 Page Not Found: Git/HEAD
ERROR - 2021-02-22 18:06:50 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2021-02-22 18:06:53 --> 404 Page Not Found: Wordpress/wp-login.php
ERROR - 2021-02-22 18:06:54 --> 404 Page Not Found: Blog/wp-login.php
ERROR - 2021-02-22 18:06:56 --> 404 Page Not Found: Wp/wp-login.php
ERROR - 2021-02-22 20:42:45 --> 404 Page Not Found: Git/HEAD
ERROR - 2021-02-22 22:03:02 --> 404 Page Not Found: Git/HEAD
