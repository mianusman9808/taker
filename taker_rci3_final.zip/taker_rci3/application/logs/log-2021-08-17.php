<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-17 02:35:31 --> 404 Page Not Found: Acceso/js
ERROR - 2021-08-17 02:35:31 --> 404 Page Not Found: Acceso/js
ERROR - 2021-08-17 20:22:40 --> 404 Page Not Found: Robotstxt/index
