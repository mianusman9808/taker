<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-05 02:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-05 08:30:16 --> 404 Page Not Found: Taker/index.php
ERROR - 2019-07-05 12:34:53 --> 404 Page Not Found: Taker/index.php
ERROR - 2019-07-05 15:30:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-05 15:30:28 --> 404 Page Not Found: Taker/index
