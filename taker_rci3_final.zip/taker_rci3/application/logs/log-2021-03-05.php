<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-05 07:27:02 --> 404 Page Not Found: Robotstxt/index
