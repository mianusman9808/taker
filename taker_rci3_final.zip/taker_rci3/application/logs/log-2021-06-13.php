<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-13 06:42:02 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2021-06-13 10:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:01:32 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2021-06-13 15:01:34 --> 404 Page Not Found: Wordpress/wp-login.php
ERROR - 2021-06-13 15:01:37 --> 404 Page Not Found: Blog/wp-login.php
ERROR - 2021-06-13 15:01:39 --> 404 Page Not Found: Wp/wp-login.php
