<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-20 10:12:56 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2021-04-20 10:12:57 --> 404 Page Not Found: Wordpress/wp-login.php
ERROR - 2021-04-20 10:12:59 --> 404 Page Not Found: Blog/wp-login.php
ERROR - 2021-04-20 10:13:00 --> 404 Page Not Found: Wp/wp-login.php
ERROR - 2021-04-20 19:12:41 --> 404 Page Not Found: Old-indexphp/index
