<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-20 06:30:04 --> 404 Page Not Found: Components/com_b2jcontact
