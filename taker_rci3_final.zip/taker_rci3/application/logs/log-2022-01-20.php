<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-20 01:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 02:14:52 --> 404 Page Not Found: Taker_ap_barrios/index
ERROR - 2022-01-20 08:22:41 --> 404 Page Not Found: Wp-includes/wp-atom.php
ERROR - 2022-01-20 14:48:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 16:10:19 --> 404 Page Not Found: Robotstxt/index
