<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-17 02:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-17 09:35:11 --> 404 Page Not Found: Taker/index
ERROR - 2019-06-17 14:03:09 --> 404 Page Not Found: Taker/index
ERROR - 2019-06-17 23:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-17 23:18:16 --> 404 Page Not Found: Robotstxt/index
