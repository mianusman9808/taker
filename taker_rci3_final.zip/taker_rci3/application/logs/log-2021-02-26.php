<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-26 15:11:19 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2021-02-26 15:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-26 16:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-26 16:28:16 --> 404 Page Not Found: Js/respond.min.js
ERROR - 2021-02-26 21:05:56 --> 404 Page Not Found: Js/html5.js
ERROR - 2021-02-26 23:35:24 --> 404 Page Not Found: Wp-loginphp/index
