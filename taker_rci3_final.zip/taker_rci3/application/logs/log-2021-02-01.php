<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-01 10:37:04 --> 404 Page Not Found: Wp-content/db-cache.php
ERROR - 2021-02-01 10:37:51 --> 404 Page Not Found: Wp-content/db-cache.php
ERROR - 2021-02-01 19:33:08 --> 404 Page Not Found: Wp/index
ERROR - 2021-02-01 19:33:13 --> 404 Page Not Found: Blog/index
ERROR - 2021-02-01 19:33:15 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-02-01 19:33:18 --> 404 Page Not Found: Site/index
ERROR - 2021-02-01 19:33:21 --> 404 Page Not Found: Cms/index
ERROR - 2021-02-01 19:33:23 --> 404 Page Not Found: Web/index
ERROR - 2021-02-01 19:33:25 --> 404 Page Not Found: News/index
ERROR - 2021-02-01 19:33:27 --> 404 Page Not Found: Home/index
ERROR - 2021-02-01 19:33:30 --> 404 Page Not Found: New/index
