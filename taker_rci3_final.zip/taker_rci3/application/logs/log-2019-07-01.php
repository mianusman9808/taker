<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-01 07:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-01 16:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-01 16:20:29 --> 404 Page Not Found: Taker/index
ERROR - 2019-07-01 23:49:06 --> 404 Page Not Found: Robotstxt/index
