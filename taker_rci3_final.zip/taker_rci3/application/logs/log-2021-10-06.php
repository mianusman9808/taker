<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-06 08:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 16:32:05 --> 404 Page Not Found: Env/index
ERROR - 2021-10-06 16:32:10 --> 404 Page Not Found: Wp-content/index
