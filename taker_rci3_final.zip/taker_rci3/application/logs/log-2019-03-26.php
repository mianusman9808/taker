<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-26 18:07:33 --> 404 Page Not Found: Robotstxt/index
