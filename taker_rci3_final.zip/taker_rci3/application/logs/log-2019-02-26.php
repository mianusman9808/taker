<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-26 06:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-26 23:36:31 --> 404 Page Not Found: Robotstxt/index
