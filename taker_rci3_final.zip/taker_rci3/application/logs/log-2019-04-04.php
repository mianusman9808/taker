<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-04 16:45:18 --> 404 Page Not Found: Robotstxt/index
