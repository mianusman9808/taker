<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-10 09:43:01 --> 404 Page Not Found: Robotstxt/index
