<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-16 14:44:15 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-07-16 17:22:58 --> 404 Page Not Found: Robotstxt/index
