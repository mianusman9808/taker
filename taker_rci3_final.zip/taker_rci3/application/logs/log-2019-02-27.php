<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-27 14:34:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-27 14:54:16 --> 404 Page Not Found: Robotstxt/index
