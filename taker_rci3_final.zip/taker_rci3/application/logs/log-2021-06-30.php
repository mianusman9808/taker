<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-30 04:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-30 16:00:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-30 21:06:34 --> 404 Page Not Found: Js/html5.js
