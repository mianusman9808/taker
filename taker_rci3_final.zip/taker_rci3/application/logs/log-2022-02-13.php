<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-13 02:18:37 --> 404 Page Not Found: Robotstxt/index
