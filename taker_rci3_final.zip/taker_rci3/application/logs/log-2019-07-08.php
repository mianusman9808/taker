<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-08 12:11:02 --> Severity: Notice --> Array to string conversion /var/www/www.taker.com.ar/html/taker_rci3/application/nusoap/nusoap.php 3125
ERROR - 2019-07-08 21:44:11 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2019-07-08 22:56:23 --> 404 Page Not Found: Robotstxt/index
