<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-12 19:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-12 21:53:16 --> 404 Page Not Found: Robotstxt/index
