<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-27 12:49:40 --> 404 Page Not Found: Taker/index.php
