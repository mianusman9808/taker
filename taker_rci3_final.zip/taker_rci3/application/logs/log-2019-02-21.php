<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-21 20:09:31 --> 404 Page Not Found: Robotstxt/index
