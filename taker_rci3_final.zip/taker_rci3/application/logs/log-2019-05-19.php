<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-19 04:23:02 --> 404 Page Not Found: Taker/index
ERROR - 2019-05-19 07:02:47 --> 404 Page Not Found: Taker/index
ERROR - 2019-05-19 18:43:53 --> 404 Page Not Found: Js/html5.js
ERROR - 2019-05-19 18:43:56 --> 404 Page Not Found: Js/respond.min.js
ERROR - 2019-05-19 22:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-19 23:17:17 --> 404 Page Not Found: Robotstxt/index
