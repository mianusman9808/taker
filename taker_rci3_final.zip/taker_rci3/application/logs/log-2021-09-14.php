<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-14 18:49:05 --> 404 Page Not Found: Robotstxt/index
