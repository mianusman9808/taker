<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-03 03:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-03 11:23:13 --> 404 Page Not Found: Old-indexphp/index
ERROR - 2021-05-03 22:39:57 --> 404 Page Not Found: Wp/index
ERROR - 2021-05-03 22:39:59 --> 404 Page Not Found: Blog/index
ERROR - 2021-05-03 22:40:01 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-05-03 22:40:03 --> 404 Page Not Found: Site/index
ERROR - 2021-05-03 22:40:05 --> 404 Page Not Found: Cms/index
ERROR - 2021-05-03 22:40:07 --> 404 Page Not Found: Web/index
ERROR - 2021-05-03 22:40:08 --> 404 Page Not Found: News/index
ERROR - 2021-05-03 22:40:10 --> 404 Page Not Found: Home/index
ERROR - 2021-05-03 22:40:12 --> 404 Page Not Found: New/index
