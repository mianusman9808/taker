<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-04 15:33:38 --> 404 Page Not Found: Taker/index
ERROR - 2019-06-04 23:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-04 23:18:34 --> 404 Page Not Found: Robotstxt/index
