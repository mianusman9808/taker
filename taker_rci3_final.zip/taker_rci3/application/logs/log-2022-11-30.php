<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-30 04:24:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:24:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:19 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:24:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 04:24:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 04:24:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:24:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:24:20 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 04:24:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:24:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:24:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:24:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 04:24:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 04:24:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:24:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:24:35 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 04:24:36 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:24:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:40 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:24:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:24:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 04:24:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 04:24:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:24:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:24:41 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 04:24:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:24:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:24:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:24:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 04:24:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 04:24:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:24:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:24:45 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 04:24:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:24:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:24:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:24:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:24:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:24:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 04:24:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 04:24:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:24:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:24:49 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 04:24:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:44:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:44:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:44:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:44:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:44:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:44:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:44:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:44:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:44:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:44:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:44:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:44:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 04:44:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 04:44:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:44:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:44:57 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 04:44:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:45:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:45:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:45:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:45:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:45:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:45:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:45:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 04:45:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 04:45:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:45:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:45:01 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 04:45:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:45:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:45:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:45:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:45:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:45:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:45:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:45:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 04:45:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 04:45:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:45:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:45:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 04:45:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:45:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:45:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:45:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:45:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:45:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:45:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:45:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 04:45:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 04:45:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:45:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:45:05 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 04:45:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:45:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:45:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:45:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:45:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:45:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 04:45:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 04:45:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 04:45:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 04:45:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 04:45:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:45:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 04:45:06 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 04:45:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 05:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 05:02:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:02:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:02:50 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 05:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 05:02:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 05:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 05:02:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:02:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:02:54 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 05:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 05:02:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 05:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 05:02:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:02:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:02:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 05:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 05:02:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:02:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 05:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 05:02:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:02:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:02:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 05:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 05:02:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:03:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:03:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:03:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:03:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:03:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:03:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:03:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:03:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:03:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:03:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:03:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:03:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:03:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 05:03:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 05:03:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:03:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:03:00 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 05:03:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 05:03:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:08:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:40 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:08:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:40 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:08:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 05:08:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 05:08:40 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:08:40 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:08:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 05:08:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 05:08:40 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:08:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:08:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:08:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 05:08:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 05:08:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:08:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:08:43 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 05:08:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 05:08:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:08:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:08:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:08:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 05:08:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 05:08:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:08:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:08:45 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 05:08:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 05:08:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:08:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:08:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:08:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 05:08:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 05:08:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:08:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:08:47 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 05:08:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 05:08:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:08:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:08:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:08:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:08:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:08:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 05:08:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 05:08:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:08:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:08:48 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 05:08:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 05:08:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:09:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:09:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:09:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:09:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:09:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:09:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:09:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:09:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:09:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:09:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:09:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:09:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:09:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 05:09:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 05:09:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:09:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:09:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 05:09:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 05:09:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:09:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:09:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:09:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:09:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:09:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:09:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:09:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:09:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:09:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:10:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 05:10:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 05:10:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:10:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:10:00 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 05:10:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 05:10:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:10:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:10:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:10:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:10:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:10:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:10:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:10:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 05:10:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 05:10:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:10:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:10:01 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 05:10:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 05:10:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:10:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:10:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:10:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:10:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:10:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:10:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:10:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 05:10:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 05:10:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:10:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:10:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 05:10:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 05:10:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:10:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:10:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:10:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:10:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:10:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 05:10:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 05:10:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 05:10:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 05:10:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 05:10:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:10:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 05:10:05 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 05:10:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 05:10:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 10:59:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\taker_rci3\taker_rci3\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2022-11-30 10:59:03 --> Unable to connect to the database
ERROR - 2022-11-30 10:59:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\taker_rci3\taker_rci3\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2022-11-30 10:59:10 --> Unable to connect to the database
ERROR - 2022-11-30 10:59:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 10:59:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 10:59:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 10:59:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 10:59:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 10:59:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 10:59:15 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 10:59:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 10:59:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 10:59:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:19 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 10:59:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:19 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 10:59:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 10:59:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 10:59:19 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 10:59:19 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 10:59:19 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 10:59:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 10:59:19 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 10:59:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 10:59:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 10:59:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 10:59:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 10:59:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 10:59:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 10:59:21 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 10:59:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 10:59:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 10:59:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 10:59:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 10:59:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 10:59:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 10:59:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 10:59:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 10:59:22 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 10:59:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 10:59:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 10:59:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 10:59:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 10:59:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 10:59:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 10:59:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 10:59:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 10:59:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 10:59:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 10:59:23 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 10:59:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 10:59:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:28:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:28:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:28:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:28:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:28:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:28:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:28:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:28:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:28:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:28:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:28:53 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:28:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:28:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:28:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:28:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:28:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:28:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:28:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:28:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:28:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:28:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:28:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:28:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:28:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:28:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:28:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:28:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:28:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:28:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:28:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:28:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:28:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:28:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:28:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:28:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:28:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:28:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:28:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:28:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:28:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:28:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:28:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:28:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:28:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:28:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:28:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:28:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:28:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:28:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:28:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:28:59 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:28:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:28:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:29:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:29:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:29:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:29:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:29:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:29:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:29:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:29:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:29:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:29:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:29:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:29:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:29:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:29:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:29:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:29:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:29:01 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:29:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:29:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:32:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:32:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:32:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:32:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:32:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:32:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:32:15 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:32:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:32:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:32:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:32:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:32:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:32:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:32:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:32:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:32:18 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:32:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:32:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:32:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:19 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:32:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:19 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:32:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:32:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:32:19 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:32:19 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:32:19 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:32:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:32:19 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:32:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:32:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:32:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:32:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:32:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:32:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:32:20 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:32:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:32:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:32:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:32:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:32:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:32:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:32:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:32:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:32:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:32:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:32:22 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:32:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:32:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:33:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:33:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:33:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:33:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:33:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:33:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:33:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:33:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:33:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:33:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:33:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:33:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:33:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:33:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:33:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:33:42 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:33:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:33:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:33:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:33:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:33:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:33:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:33:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:33:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:33:43 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:33:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:33:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:33:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:33:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:33:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:33:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:33:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:33:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:33:44 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:33:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:33:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:33:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:33:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:33:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:33:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:33:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:33:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:33:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:33:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:33:46 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:33:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:33:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:39:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:39:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:39:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:39:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:22 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:39:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:39:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:39:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:39:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:39:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:39:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:25 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:39:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:39:26 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:39:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:39:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:39:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:39:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:27 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:39:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:39:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:39:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:39:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:39:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:39:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:28 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:39:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:39:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:29 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:39:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:29 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:39:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:39:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:39:29 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:29 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:30 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:39:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:39:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:39:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:39:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:39:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:39:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:39:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:39:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:39:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:39:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:39:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:40:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:40:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:40:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:40:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:40:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:40:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:40:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:40:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:40:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:40:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:40:01 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:40:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:40:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:40:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:40:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:40:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:40:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:40:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:40:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:40:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:40:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:40:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:40:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:40:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:40:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:40:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:40:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:40:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:40:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:40:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:40:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:40:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:40:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:40:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:40:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:40:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:40:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:40:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:40:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:40:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:40:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:40:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:40:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:40:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:40:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:40:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:40:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:40:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:40:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:40:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:40:05 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:40:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:40:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:44:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:44:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:44:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:44:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:44:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:44:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:44:47 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:44:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:44:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:44:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:44:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:44:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:44:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:44:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:44:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:44:48 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:44:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:44:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:44:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:44:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:44:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:44:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:44:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:44:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:44:50 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:44:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:44:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:44:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:44:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:44:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:44:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:44:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:44:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:44:51 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:44:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:44:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:44:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:52 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:44:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-30 11:44:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-30 11:44:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-30 11:44:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-30 11:44:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-30 11:44:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:44:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-30 11:44:53 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-30 11:44:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\inline_renderer.cls.php 110
ERROR - 2022-11-30 11:44:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
