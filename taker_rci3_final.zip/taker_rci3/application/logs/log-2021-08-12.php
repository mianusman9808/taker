<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-12 09:55:23 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-08-12 09:55:39 --> 404 Page Not Found: Well-known/index
ERROR - 2021-08-12 09:55:56 --> 404 Page Not Found: Sites/default
ERROR - 2021-08-12 09:56:12 --> 404 Page Not Found: Admin/controller
ERROR - 2021-08-12 09:56:28 --> 404 Page Not Found: Uploads/index
ERROR - 2021-08-12 20:13:59 --> 404 Page Not Found: Robotstxt/index
