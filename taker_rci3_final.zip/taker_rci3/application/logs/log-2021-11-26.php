<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-26 14:23:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 19:39:29 --> 404 Page Not Found: Cgi-bin/mt
ERROR - 2021-11-26 19:39:34 --> 404 Page Not Found: Mt/mt-atom.cgi
ERROR - 2021-11-26 19:40:20 --> 404 Page Not Found: Cgi-bin/mt-atom.cgi
ERROR - 2021-11-26 19:40:25 --> 404 Page Not Found: Mt-atomcgi/index
ERROR - 2021-11-26 19:40:30 --> 404 Page Not Found: Cgi-bin/MT
ERROR - 2021-11-26 19:40:35 --> 404 Page Not Found: MT/mt-atom.cgi
ERROR - 2021-11-26 19:40:41 --> 404 Page Not Found: Mtos/mt-atom.cgi
ERROR - 2021-11-26 19:40:47 --> 404 Page Not Found: Cms/mt-atom.cgi
ERROR - 2021-11-26 19:40:57 --> 404 Page Not Found: Blog/mt-atom.cgi
ERROR - 2021-11-26 19:41:06 --> 404 Page Not Found: Cgi/mt-atom.cgi
