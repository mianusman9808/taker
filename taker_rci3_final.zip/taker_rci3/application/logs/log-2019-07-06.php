<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-06 22:46:41 --> 404 Page Not Found: Robotstxt/index
