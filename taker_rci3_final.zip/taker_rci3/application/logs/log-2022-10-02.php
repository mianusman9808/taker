<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-02 10:35:49 --> Severity: Warning --> Creating default object from empty value /mnt/efs/html/taker_rci3/application/nusoap/nusoap.php 4844
ERROR - 2022-10-02 10:35:51 --> Severity: Notice --> A non well formed numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/style.cls.php 467
ERROR - 2022-10-02 10:35:51 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:51 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:51 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:51 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:51 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:51 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:51 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_cell_frame_reflower.cls.php 99
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_cell_frame_reflower.cls.php 99
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Notice --> A non well formed numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/style.cls.php 467
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_frame_reflower.cls.php 557
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_frame_reflower.cls.php 558
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 48
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:35:52 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 48
ERROR - 2022-10-02 10:44:03 --> Severity: Warning --> Creating default object from empty value /mnt/efs/html/taker_rci3/application/nusoap/nusoap.php 4844
ERROR - 2022-10-02 10:44:04 --> Severity: Notice --> A non well formed numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/style.cls.php 467
ERROR - 2022-10-02 10:44:04 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:04 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:04 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:04 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:04 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_cell_frame_reflower.cls.php 99
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_cell_frame_reflower.cls.php 99
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Notice --> A non well formed numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/style.cls.php 467
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_frame_reflower.cls.php 557
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_frame_reflower.cls.php 558
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 48
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 10:44:05 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 48
ERROR - 2022-10-02 12:45:13 --> Severity: Warning --> Creating default object from empty value /mnt/efs/html/taker_rci3/application/nusoap/nusoap.php 4844
ERROR - 2022-10-02 12:45:16 --> Severity: Notice --> A non well formed numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/style.cls.php 467
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_cell_frame_reflower.cls.php 99
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_cell_frame_reflower.cls.php 99
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:16 --> Severity: Notice --> A non well formed numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/style.cls.php 467
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_frame_reflower.cls.php 557
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_frame_reflower.cls.php 558
ERROR - 2022-10-02 12:45:16 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 48
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 12:45:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 48
ERROR - 2022-10-02 13:00:15 --> Severity: Warning --> Creating default object from empty value /mnt/efs/html/taker_rci3/application/nusoap/nusoap.php 4844
ERROR - 2022-10-02 13:00:17 --> Severity: Notice --> A non well formed numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/style.cls.php 467
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_cell_frame_reflower.cls.php 99
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_cell_frame_reflower.cls.php 99
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Notice --> A non well formed numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/style.cls.php 467
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_frame_reflower.cls.php 557
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_frame_reflower.cls.php 558
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 13:00:17 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 13:00:18 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 48
ERROR - 2022-10-02 15:25:11 --> Severity: Warning --> Creating default object from empty value /mnt/efs/html/taker_rci3/application/nusoap/nusoap.php 4844
ERROR - 2022-10-02 15:25:13 --> Severity: Notice --> A non well formed numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/style.cls.php 467
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_cell_frame_reflower.cls.php 99
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_cell_frame_reflower.cls.php 99
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Notice --> A non well formed numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/style.cls.php 467
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_frame_reflower.cls.php 557
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/table_frame_reflower.cls.php 558
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 110
ERROR - 2022-10-02 15:25:13 --> Severity: Warning --> A non-numeric value encountered /mnt/efs/html/taker_dompdf/dompdf/include/inline_renderer.cls.php 48
ERROR - 2022-10-02 16:18:08 --> 404 Page Not Found: Wp-admin/css
ERROR - 2022-10-02 16:18:20 --> 404 Page Not Found: Well-known/index
ERROR - 2022-10-02 16:18:35 --> 404 Page Not Found: Sites/default
ERROR - 2022-10-02 16:18:49 --> 404 Page Not Found: Admin/controller
ERROR - 2022-10-02 16:19:04 --> 404 Page Not Found: Uploads/index
ERROR - 2022-10-02 16:19:31 --> 404 Page Not Found: Files/index
ERROR - 2022-10-02 19:44:03 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-10-02 21:58:18 --> 404 Page Not Found: Stylephp/index
