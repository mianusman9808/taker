<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-29 14:10:06 --> 404 Page Not Found: Robotstxt/index
