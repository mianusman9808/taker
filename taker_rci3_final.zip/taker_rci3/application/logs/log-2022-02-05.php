<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-05 03:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-05 16:04:05 --> 404 Page Not Found: Js/html5.js
ERROR - 2022-02-05 16:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-05 17:22:22 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-02-05 20:51:14 --> 404 Page Not Found: Env/index
ERROR - 2022-02-05 20:51:15 --> 404 Page Not Found: Wp-content/index
