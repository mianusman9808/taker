<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-08 15:28:07 --> 404 Page Not Found: Robotstxt/index
