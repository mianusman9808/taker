<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-14 08:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-14 09:21:54 --> 404 Page Not Found: Taker/index.php
ERROR - 2019-06-14 11:16:47 --> 404 Page Not Found: Robotstxt/index
