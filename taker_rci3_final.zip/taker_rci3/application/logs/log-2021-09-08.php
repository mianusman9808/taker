<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-08 14:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-08 17:28:52 --> 404 Page Not Found: Robotstxt/index
