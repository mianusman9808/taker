<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-20 22:11:01 --> 404 Page Not Found: Wp-loginphp/index
