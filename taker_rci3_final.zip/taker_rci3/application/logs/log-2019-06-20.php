<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-20 09:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-20 23:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-20 23:26:36 --> 404 Page Not Found: Robotstxt/index
