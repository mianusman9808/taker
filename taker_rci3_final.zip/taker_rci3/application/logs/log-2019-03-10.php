<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-10 22:41:12 --> 404 Page Not Found: Robotstxt/index
