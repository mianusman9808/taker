<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-08 08:50:14 --> 404 Page Not Found: Robotstxt/index
