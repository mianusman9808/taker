<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-24 13:56:15 --> 404 Page Not Found: Robotstxt/index
