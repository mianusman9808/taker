<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-16 12:55:36 --> 404 Page Not Found: Acceso/js
ERROR - 2019-05-16 12:55:37 --> 404 Page Not Found: Acceso/js
ERROR - 2019-05-16 18:37:55 --> 404 Page Not Found: Js/html5.js
ERROR - 2019-05-16 18:37:57 --> 404 Page Not Found: Js/respond.min.js
ERROR - 2019-05-16 18:38:02 --> 404 Page Not Found: Js/respond.min.js
ERROR - 2019-05-16 18:38:14 --> 404 Page Not Found: Js/html5.js
