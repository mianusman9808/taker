<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-26 18:38:37 --> 404 Page Not Found: Robotstxt/index
