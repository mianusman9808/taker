<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-27 00:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-27 14:12:30 --> 404 Page Not Found: Env/index
ERROR - 2021-07-27 15:46:26 --> 404 Page Not Found: Robotstxt/index
