<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-30 12:55:04 --> 404 Page Not Found: Libraries/libraries.php
ERROR - 2019-06-30 12:55:07 --> 404 Page Not Found: Libraries/libraries.php
ERROR - 2019-06-30 22:44:25 --> 404 Page Not Found: Libraries/libraries.php
ERROR - 2019-06-30 22:44:27 --> 404 Page Not Found: Libraries/libraries.php
