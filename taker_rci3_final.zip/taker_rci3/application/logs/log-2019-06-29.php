<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-29 06:24:47 --> 404 Page Not Found: Admin/images
ERROR - 2019-06-29 06:24:59 --> 404 Page Not Found: Admin/login.php
ERROR - 2019-06-29 06:25:08 --> 404 Page Not Found: Templates/system
ERROR - 2019-06-29 06:25:28 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2019-06-29 06:25:33 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2019-06-29 07:46:47 --> 404 Page Not Found: Components/com_b2jcontact
ERROR - 2019-06-29 07:46:47 --> 404 Page Not Found: Components/com_jdownloads
ERROR - 2019-06-29 11:35:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-29 22:56:42 --> 404 Page Not Found: Robotstxt/index
