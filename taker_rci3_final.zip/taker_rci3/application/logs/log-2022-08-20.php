<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-20 02:35:42 --> 404 Page Not Found: Robotstxt/index
