<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-16 11:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-01-16 11:59:58 --> 404 Page Not Found: Atomxml/index
ERROR - 2021-01-16 17:45:08 --> 404 Page Not Found: Js/html5.js
ERROR - 2021-01-16 18:36:03 --> 404 Page Not Found: Js/respond.min.js
ERROR - 2021-01-16 22:33:11 --> 404 Page Not Found: Wp-loginphp/index
