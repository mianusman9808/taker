<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-20 00:30:56 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-07-20 19:57:03 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-07-20 19:57:05 --> 404 Page Not Found: Administrator/help
ERROR - 2022-07-20 19:57:06 --> 404 Page Not Found: Administrator/language
ERROR - 2022-07-20 19:57:08 --> 404 Page Not Found: Plugins/system
ERROR - 2022-07-20 19:57:09 --> 404 Page Not Found: Administrator/index
ERROR - 2022-07-20 19:57:11 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2022-07-20 19:57:13 --> 404 Page Not Found: Admin/view
ERROR - 2022-07-20 19:57:15 --> 404 Page Not Found: Admin/includes
ERROR - 2022-07-20 19:57:16 --> 404 Page Not Found: Images/editor
ERROR - 2022-07-20 19:57:18 --> 404 Page Not Found: Js/header-rollup-554.js
ERROR - 2022-07-20 19:57:19 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-07-20 19:57:21 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2022-07-20 19:57:22 --> 404 Page Not Found: Env/index
ERROR - 2022-07-20 19:57:25 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2022-07-20 19:57:27 --> 404 Page Not Found: Wordpress/wp-admin
ERROR - 2022-07-20 19:57:28 --> 404 Page Not Found: Wp/wp-admin
ERROR - 2022-07-20 19:57:30 --> 404 Page Not Found: Blog/wp-admin
ERROR - 2022-07-20 19:57:31 --> 404 Page Not Found: Test/wp-admin
ERROR - 2022-07-20 19:57:33 --> 404 Page Not Found: Site/wp-admin
ERROR - 2022-07-20 23:56:10 --> 404 Page Not Found: Robotstxt/index
