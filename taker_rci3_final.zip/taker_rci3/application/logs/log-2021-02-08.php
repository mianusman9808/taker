<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-08 05:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-02-08 21:24:06 --> 404 Page Not Found: Robotstxt/index
