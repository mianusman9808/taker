<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-15 01:47:09 --> 404 Page Not Found: Taker/assets
ERROR - 2022-05-15 05:27:17 --> 404 Page Not Found: Taker/assets
ERROR - 2022-05-15 08:49:21 --> 404 Page Not Found: Js/html5.js
ERROR - 2022-05-15 10:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-05-15 16:15:23 --> 404 Page Not Found: Kcfinder/upload.php
ERROR - 2022-05-15 16:15:25 --> 404 Page Not Found: Asset/kcfinder
ERROR - 2022-05-15 16:15:28 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2022-05-15 16:15:31 --> 404 Page Not Found: Js/kcfinder
ERROR - 2022-05-15 16:15:33 --> 404 Page Not Found: Assets/js
