<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-25 00:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-25 00:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-25 00:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-25 00:43:09 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-25 11:11:11 --> 404 Page Not Found: Taker/index.php
