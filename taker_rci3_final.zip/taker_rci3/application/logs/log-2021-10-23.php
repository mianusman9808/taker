<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-23 03:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 04:21:41 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-10-23 04:21:41 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2021-10-23 04:21:41 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-10-23 04:21:41 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-10-23 04:21:41 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-10-23 04:21:42 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-10-23 04:21:42 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-10-23 04:21:42 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-10-23 04:21:42 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-10-23 04:21:42 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-10-23 04:21:42 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-10-23 04:21:43 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-10-23 04:21:43 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-10-23 04:21:43 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-10-23 04:21:43 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-10-23 04:21:43 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-10-23 04:21:43 --> 404 Page Not Found: Sito/wp-includes
