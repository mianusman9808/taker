<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-30 03:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-30 06:04:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-30 13:01:08 --> Severity: Notice --> Uninitialized string offset: -1 /var/www/www.taker.com.ar/html/taker_rci3/application/core/MY_Controller.php 50
ERROR - 2019-05-30 16:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-30 23:13:27 --> 404 Page Not Found: Robotstxt/index
