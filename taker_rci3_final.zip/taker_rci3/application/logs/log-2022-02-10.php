<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-10 02:16:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-10 05:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-10 06:35:52 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2022-02-10 06:35:53 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2022-02-10 06:35:57 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-02-10 06:35:57 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-02-10 06:35:58 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-02-10 06:35:59 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-02-10 06:35:59 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-02-10 06:36:00 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-02-10 06:36:00 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-02-10 06:36:00 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-02-10 06:36:01 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-02-10 06:36:01 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-02-10 06:36:02 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-02-10 06:36:02 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-02-10 06:36:02 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-02-10 06:36:02 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-02-10 06:36:03 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-02-10 06:36:04 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-02-10 22:42:56 --> 404 Page Not Found: Robotstxt/index
