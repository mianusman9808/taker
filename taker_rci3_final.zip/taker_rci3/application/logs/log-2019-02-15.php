<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-15 20:55:38 --> 404 Page Not Found: Robotstxt/index
