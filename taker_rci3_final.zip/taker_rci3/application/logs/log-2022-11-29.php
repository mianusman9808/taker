<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-29 13:20:56 --> Severity: Notice --> Undefined variable: contacto C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-29 13:20:56 --> Severity: Warning --> include_once(C:\xampp\php\pear): failed to open stream: Permission denied C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-29 13:20:56 --> Severity: Warning --> include_once(): Failed opening '' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\taker_rci3\taker\inc\footer.php 66
ERROR - 2022-11-29 13:24:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:24:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:24:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:24:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:24:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 13:24:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 13:24:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:24:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:24:06 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 13:24:07 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:24:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:24:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:24:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:24:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:24:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 13:24:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 13:24:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:24:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:24:10 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 13:24:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:24:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:24:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:24:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:24:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:24:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 13:24:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 13:24:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:24:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:24:14 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 13:24:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:24:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:24:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:24:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:24:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:24:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 13:24:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 13:24:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:24:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:24:15 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 13:24:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:24:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:24:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:24:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:24:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:24:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:24:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 13:24:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 13:24:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:24:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:24:17 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 13:24:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:26:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:26:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:26:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:26:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:26:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 13:26:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 13:26:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:26:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:26:32 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 13:26:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:26:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:26:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:26:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:26:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:26:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 13:26:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 13:26:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:26:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:26:35 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 13:26:36 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:26:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:26:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:26:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:26:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:26:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 13:26:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 13:26:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:26:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:26:37 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 13:26:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:26:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:26:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:26:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:26:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:26:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 13:26:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 13:26:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:26:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:26:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 13:26:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:26:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:26:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:26:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:26:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:26:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:26:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 13:26:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 13:26:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:26:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:26:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 13:26:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:55:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:55:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:55:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:55:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 13:55:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 13:55:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:55:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:55:17 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 13:55:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:55:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:55:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:55:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:55:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 13:55:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 13:55:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:55:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:55:20 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 13:55:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:55:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:55:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:55:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:55:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 13:55:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 13:55:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:55:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:55:22 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 13:55:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:55:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:55:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:55:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:55:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 13:55:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 13:55:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:55:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:55:23 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 13:55:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:55:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 13:55:24 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:55:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 13:55:24 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 13:55:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 13:55:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 13:55:24 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:55:24 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 13:55:24 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 13:55:24 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:16:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:16:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:16:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:16:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:16:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:16:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:16:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:16:18 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:16:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:16:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:16:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:16:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:16:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:16:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:16:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:16:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:16:20 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:16:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:16:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:16:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:16:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:16:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:16:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:16:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:16:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:16:21 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:16:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:16:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:16:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:16:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:16:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:16:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:16:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:16:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:16:23 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:16:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:16:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:16:24 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:16:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:16:24 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:16:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:16:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:16:24 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:16:24 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:16:24 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:16:24 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:19:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:19:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:19:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:19:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:19:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:19:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:19:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:19:50 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:19:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:19:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:19:52 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:19:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:19:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:19:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:19:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:19:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:19:53 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:19:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:19:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:19:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:19:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:19:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:19:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:19:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:19:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:19:54 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:19:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:19:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:19:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:19:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:19:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:19:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:19:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:19:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:19:55 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:19:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:19:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:19:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:19:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:19:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:19:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:19:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:19:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:19:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:19:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:19:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:22:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:22:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:22:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:22:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:22:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:22:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:22:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:22:23 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:22:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:22:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:22:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:22:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:22:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:22:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:22:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:22:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:22:25 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:22:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:22:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:22:26 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:22:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:26 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:22:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:22:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:22:26 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:22:26 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:22:26 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:22:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:22:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:22:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:22:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:22:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:22:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:22:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:22:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:22:28 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:22:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:22:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:22:29 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:22:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:22:29 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:22:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:22:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:22:29 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:22:29 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:22:29 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:22:29 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:23:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:23:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:23:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:00 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:23:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:23:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:23:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:23:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:02 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:23:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:23:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:23:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:23:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:23:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:23:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:23:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:23:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:05 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:23:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:23:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:23:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:23:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:06 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:23:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:23:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:23:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:23:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:48 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:23:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:23:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:23:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:23:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:51 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:23:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:23:52 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:23:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:23:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:53 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:23:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:23:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:23:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:23:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:54 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:23:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:23:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:23:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:23:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:23:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:23:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:23:55 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:23:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:26:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:26:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:26:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:26:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:26:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:26:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:26:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:26:50 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:26:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:26:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:26:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:26:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:26:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:26:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:26:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:26:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:26:54 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:26:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:26:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:26:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:26:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:26:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:26:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:26:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:26:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:26:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:26:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:26:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:26:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:26:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:26:57 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:26:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:26:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:26:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:26:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:26:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:26:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:26:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:26:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:26:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:26:59 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:26:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:28:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:28:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:28:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:28:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:28:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:28:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:28:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:28:30 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:28:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:28:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:28:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:28:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:28:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:28:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:28:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:28:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:28:33 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:28:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:28:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:28:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:28:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:28:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:28:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:28:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:28:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:28:34 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:28:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:28:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:28:36 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:28:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:36 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:28:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:28:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:28:36 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:28:36 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:28:36 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:28:36 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:28:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:28:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:28:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:28:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:28:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:28:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:28:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:28:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:28:37 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:28:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:29:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:29:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:29:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:10 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:29:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:29:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:29:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:29:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:13 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:29:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:29:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:29:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:29:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:14 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:29:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:29:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:29:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:29:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:15 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:29:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:29:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:29:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:29:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:17 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:29:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:29:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:29:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:29:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:51 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:29:52 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:29:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:29:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:29:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:55 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:29:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:29:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:29:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:29:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:29:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:29:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:29:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:29:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:29:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:29:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:29:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:29:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:29:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:29:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:29:59 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:29:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:56:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:56:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:56:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:56:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:56:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:56:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:56:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:56:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:10 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:56:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:56:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:56:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:56:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:56:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:56:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:56:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:56:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:56:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:13 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:56:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:56:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:56:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:56:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:56:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:56:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:56:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:56:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:56:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:14 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:56:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:56:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:56:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:56:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:56:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:56:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:56:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:56:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:56:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:16 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:56:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:56:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:56:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:56:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:56:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:56:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:56:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:56:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:56:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:56:17 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:56:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:58:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:58:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:58:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:58:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:58:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:58:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:58:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:58:45 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:58:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:58:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:58:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:58:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:58:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:58:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:58:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:58:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:58:48 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:58:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:58:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:58:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:58:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:58:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:58:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:58:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:58:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:58:50 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:58:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:58:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:58:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:58:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:58:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:58:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:58:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:58:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:58:51 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:58:52 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:58:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 14:58:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:58:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 14:58:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 14:58:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 14:58:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 14:58:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:58:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 14:58:53 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 14:58:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:00:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:00:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:00:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:00:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:00:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:00:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:00:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:00:06 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:00:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:00:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:00:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:00:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:00:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:00:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:00:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:00:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:00:09 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:00:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:00:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:00:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:00:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:00:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:00:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:00:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:00:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:00:10 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:00:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:00:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:00:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:00:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:00:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:00:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:00:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:00:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:00:12 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:00:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:00:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:00:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:00:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:00:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:00:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:00:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:00:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:00:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:00:13 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:00:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:01:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:01:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:01:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:01:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:01:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:11 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:01:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:01:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:01:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:01:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:01:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:01:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:15 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:01:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:01:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:01:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:01:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:01:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:01:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:16 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:01:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:01:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:01:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:01:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:01:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:01:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:18 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:01:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:01:19 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:01:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:19 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:01:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:01:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:01:19 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:19 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:19 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:01:19 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:01:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:01:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:01:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:01:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:01:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:55 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:01:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:01:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:01:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:01:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:01:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:01:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:01:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:01:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:01:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:01:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:01:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:02:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:02:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:02:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:00 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:02:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:02:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:02:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:02:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:02:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:02:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:01 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:02:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:02:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:02:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:02:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:02:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:02:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:02 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:02:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:02:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:02:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:02:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:02:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:02:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:02:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:02:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:02:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:02:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:02:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:02:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:41 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:02:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:02:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:02:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:02:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:02:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:02:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:43 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:02:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:02:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:02:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:02:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:02:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:02:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:44 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:02:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:02:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:02:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:02:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:02:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:02:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:02:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:02:46 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:02:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:04:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:04:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:04:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:04:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:04:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:04:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:04:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:04:21 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:04:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:04:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:04:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:04:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:04:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:04:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:04:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:04:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:04:33 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:04:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:04:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:04:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:04:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:04:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:04:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:04:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:04:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:04:44 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:04:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:04:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:04:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:04:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:04:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:04:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:04:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:04:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:04:54 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:04:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:04:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:04:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:04:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:04:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:04:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:04:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:04:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:04:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:04:55 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:04:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:09:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:09:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:09:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:09:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:09:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:09:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:09:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:09:22 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:09:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:09:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:09:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:09:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:09:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:09:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:09:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:09:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:09:25 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:09:26 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:09:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:09:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:09:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:09:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:09:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:09:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:09:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:09:27 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:09:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:09:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:09:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:09:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:09:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:09:28 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:09:29 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:09:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:09:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:09:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:09:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:09:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:09:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:09:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:09:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:09:30 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:09:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:31:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:31:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:31:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:31:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:31:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:31:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:31:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:31:50 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:31:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:31:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:31:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:31:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:31:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:31:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:31:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:31:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:31:54 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:31:54 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:31:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:31:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:31:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:31:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:31:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:31:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:31:55 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:31:55 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:31:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:31:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:31:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:31:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:31:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:31:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:31:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:31:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:31:57 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:31:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:31:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:31:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:31:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:31:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:31:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:31:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:31:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:31:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:31:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:31:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:33:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:33:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:33:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:33:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:33:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:33:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:33:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:33:09 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:33:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:33:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:33:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:33:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:33:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:33:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:33:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:33:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:33:11 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:33:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:33:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:33:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:33:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:33:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:33:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:33:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:33:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:33:13 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:33:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:33:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:33:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:33:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:33:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:33:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:33:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:33:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:33:14 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:33:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:33:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:33:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:33:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:33:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:33:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:33:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:33:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:33:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:33:16 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:33:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:37:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:37:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:37:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:37:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:37:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:37:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:37:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:37:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:37:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:37:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:37:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:37:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:37:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:38:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:38:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:38:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:00 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:38:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:38:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:38:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:38:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:02 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:38:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:38:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:38:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:38:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:38:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:38:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:38:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:38:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:38:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:38:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:38:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:38:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:30 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:38:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:38:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:38:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:38:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:33 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:38:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:38:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:38:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:38:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:34 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:38:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:38:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:38:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:38:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:35 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:38:36 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:38:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:38:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:38:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:37 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:38:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:38:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:38:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:38:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:38:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:38:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:38:57 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:38:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:39:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:39:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:39:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:39:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:39:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:39:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:39:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:39:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:39:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:39:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:39:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:39:00 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:39:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:39:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:39:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:39:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:39:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:39:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:39:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:39:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:39:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:39:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:39:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:39:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:39:02 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:39:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:39:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:39:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:39:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:39:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:39:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:39:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:39:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:39:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:39:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:39:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:39:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:39:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:39:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:39:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 15:39:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:39:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:39:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:39:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:39:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 15:39:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 15:39:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 15:39:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 15:39:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:39:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 15:39:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 15:39:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:04:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:04:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:04:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:04:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:04:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:04:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:04:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:04:10 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:04:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:04:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:04:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:04:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:04:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:04:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:04:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:04:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:04:13 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:04:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:04:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:04:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:04:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:04:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:04:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:04:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:04:14 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:04:14 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:04:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:04:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:04:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:04:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:04:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:04:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:04:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:04:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:04:16 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:04:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:04:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:04:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:04:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:04:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:04:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:04:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:04:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:04:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:04:17 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:04:17 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:06:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:06:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:06:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:06:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:06:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:06:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:06:23 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:06:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:06:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:06:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:26 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:06:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:06:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:06:26 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:06:26 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:06:26 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:06:26 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:06:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:06:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:06:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:06:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:06:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:06:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:06:27 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:06:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:06:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:06:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:06:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:06:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:06:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:06:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:06:28 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:06:29 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:06:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:06:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:06:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:06:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:06:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:06:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:06:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:06:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:06:30 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:06:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:08:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:08:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:08:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:08:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:08:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:08:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:08:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:08:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:08:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:08:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:08:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:08:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:08:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:08:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:08:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:08:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:08:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:08:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:08:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:08:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:08:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:08:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:08:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:08:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:08:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:08:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:08:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:08:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:08:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:08:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:08:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:08:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:08:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:08:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:09:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:09:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:09:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:09:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:09:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:09:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:09:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:09:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:09:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:09:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:09:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:09:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:09:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:09:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:09:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:09:00 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:09:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:09:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:09:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:09:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:09:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:09:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:09:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:09:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:09:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:09:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:09:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:09:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:09:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:09:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:09:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:09:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:09:01 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:09:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:09:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:09:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:09:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:09:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:09:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:09:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:09:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:09:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:09:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:09:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:09:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:09:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:09:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:09:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:09:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:09:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:09:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:10:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:10:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:10:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:10:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:10:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:10:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:10:35 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:10:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:10:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:10:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:10:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:10:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:10:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:10:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:10:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:10:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:10:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:40 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:10:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:40 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:10:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:10:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:10:40 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:10:40 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:10:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:10:40 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:10:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:10:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:10:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:10:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:10:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:10:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:10:42 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:10:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:10:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:10:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:10:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:10:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:10:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:10:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:10:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:10:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:10:43 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:10:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:11:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:11:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:11:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:11:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:11:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:11:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:11:16 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:11:16 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:11:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:11:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:11:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:11:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:11:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:11:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:11:21 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:11:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:11:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:11:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:11:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:11:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:11:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:11:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:11:22 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:11:22 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:11:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:11:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:11:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:11:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:11:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:11:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:11:23 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:11:24 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:11:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:11:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:11:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:11:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:11:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:11:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:11:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:11:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:11:25 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:11:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:13:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:13:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:13:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:13:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:13:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:13:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:13:44 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:13:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:13:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:13:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:13:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:13:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:13:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:13:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:13:48 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:13:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:13:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:13:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:13:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:13:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:13:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:13:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:13:49 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:13:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:13:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:13:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:13:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:13:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:13:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:13:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:13:51 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:13:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:13:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:52 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:13:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:13:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:13:52 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:13:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:13:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:13:52 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:13:52 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:13:52 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:13:52 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:15:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:15:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:15:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:15:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:15:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:15:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:15:43 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:15:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:15:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:15:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:15:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:15:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:15:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:15:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:15:45 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:15:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:15:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:15:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:15:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:15:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:15:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:15:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:15:47 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:15:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:15:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:15:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:15:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:15:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:15:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:15:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:15:48 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:15:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:15:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:15:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:15:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:15:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:15:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:15:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:15:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:15:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:15:50 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:15:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:18:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:18:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:18:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:18:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:18:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:18:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:18:05 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:18:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:18:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:18:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:18:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:18:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:18:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:18:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:18:08 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:18:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:18:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:18:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:18:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:18:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:18:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:18:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:18:09 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:18:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:18:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:18:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:18:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:18:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:18:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:18:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:18:10 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:18:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:18:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:18:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:18:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:18:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:18:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:18:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:18:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:18:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:18:12 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:18:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:25:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:25:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:25:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:25:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:25:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:25:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:25:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:25:04 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:25:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:07 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:25:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:07 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:25:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:07 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:25:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:25:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:25:07 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:25:07 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:25:07 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:25:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:25:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:08 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:25:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:25:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:25:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:25:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:25:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:25:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:25:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:25:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:10 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:25:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:25:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:25:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:25:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:25:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:25:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:25:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:25:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:25:11 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:25:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:25:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:25:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:25:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:25:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:25:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:25:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:28:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:28:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:28:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:28:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:28:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:28:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:28:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:28:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:28:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:28:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:28:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:28:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:28:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:28:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:28:06 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:28:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:28:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:07 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:28:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:07 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:28:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:28:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:28:07 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:28:07 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:28:07 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:28:07 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:28:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:28:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:28:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:28:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:28:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:28:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:28:08 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:28:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:28:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:28:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:28:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:28:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:28:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:28:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:28:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:28:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:28:10 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:28:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:30:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:30:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:30:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:30:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:30:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:30:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:30:27 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:30:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:30:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:30:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:30:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:30:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:30:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:30:30 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:30:30 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:30:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:30:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:30:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:30:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:30:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:30:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:30:32 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:30:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:30:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:30:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:30:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:30:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:30:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:30:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:30:34 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:30:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:30:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:30:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:30:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:30:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:30:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:30:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:30:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:30:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:30:35 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:30:36 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:33:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:52 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:33:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:33:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:33:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:33:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:33:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:52 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:33:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:33:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:33:52 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:33:52 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:33:52 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:33:53 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:33:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:33:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:33:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:33:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:33:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:33:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:33:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:33:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:33:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:33:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:33:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:33:56 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:33:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:33:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:33:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:33:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:33:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:33:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:33:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:33:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:33:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:33:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:33:57 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:33:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:33:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:58 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:33:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:33:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:33:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:33:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:33:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:33:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:33:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:33:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:33:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:33:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:33:59 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:33:59 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:34:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:34:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:34:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:34:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:34:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:34:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:34:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:34:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:34:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:34:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:34:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:34:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:34:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:34:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:34:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:34:00 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:34:00 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:35:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:35:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:35:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:35:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:35:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:35:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:35:20 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:35:20 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:35:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:35:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:35:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:35:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:35:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:35:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:35:23 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:35:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:35:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:24 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:35:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:24 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:35:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:35:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:35:24 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:35:24 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:35:24 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:35:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:35:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:25 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:35:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:26 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:35:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:35:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:35:26 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:35:26 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:35:26 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:35:26 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:35:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:35:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:35:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:35:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:35:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:35:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:35:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:35:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:35:27 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:35:27 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:36:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:36:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:01 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:01 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:36:02 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:36:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:36:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:05 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:36:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:07 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:07 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:36:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:36:07 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:07 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:07 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:36:07 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:36:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:36:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:08 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:36:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:36:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:36:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:10 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:36:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:31 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:31 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:31 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:31 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:31 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:31 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:31 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:31 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:31 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:31 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:31 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:31 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:36:31 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:36:31 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:31 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:31 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:36:31 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:36:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:36:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:33 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:33 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:36:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:36:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:36:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:35 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:36:35 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:36 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:36 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:36:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:36:36 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:36 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:36 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:36:36 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:36:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:36:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:36:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:36:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:36:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:36:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:36:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:39:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:39:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:39:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:39:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:39:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:39:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:39:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:39:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:39:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:39:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:39:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:39:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:39:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:39:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:39:42 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:39:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:39:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:39:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:39:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:39:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:39:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:39:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:39:43 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:39:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:39:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:39:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:39:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:39:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:39:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:39:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:39:45 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:39:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:39:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:39:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:39:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:39:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:39:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:39:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:39:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:39:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:39:46 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:39:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:41:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:41:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:41:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:41:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:41:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:41:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:41:43 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:41:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:41:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:41:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:41:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:41:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:41:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:41:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:41:46 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:41:46 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:41:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:41:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:41:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:41:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:41:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:41:47 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:41:47 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:41:48 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:41:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:41:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:41:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:41:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:41:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:41:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:41:49 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:41:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:41:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:41:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:41:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:41:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:41:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:41:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:41:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:41:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:41:50 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:41:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:44:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:44:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:44:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:44:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:44:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:44:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:44:37 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:44:37 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:44:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:40 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:44:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:40 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:44:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:44:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:44:40 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:44:40 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:44:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:44:40 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:44:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:44:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:44:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:44:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:44:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:44:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:44:41 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:44:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:44:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:44:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:44:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:44:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:44:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:44:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:44:43 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:44:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:44:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:44:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:44:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:44:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:44:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:44:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:44:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:44:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:44:44 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:44:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:46:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:46:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:46:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:46:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:46:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:46:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:46:05 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:46:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:46:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:08 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:46:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:46:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:46:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:46:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:46:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:46:09 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:46:09 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:46:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:46:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:46:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:46:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:46:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:46:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:46:10 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:46:10 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:46:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:46:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:46:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:46:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:46:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:46:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:46:11 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:46:11 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:46:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:46:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:46:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:46:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:46:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:46:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:46:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:46:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:46:12 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:46:13 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:47:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:47:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:47:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:47:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:47:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:47:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:47:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:47:38 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:47:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:47:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:47:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:47:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:47:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:47:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:47:41 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:47:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:47:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:47:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:47:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:47:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:47:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:47:42 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:47:42 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:47:43 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:47:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:47:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:47:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:47:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:47:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:47:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:47:44 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:47:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:47:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:47:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_cell_frame_reflower.cls.php 99
ERROR - 2022-11-29 17:47:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\page_frame_decorator.cls.php 439
ERROR - 2022-11-29 17:47:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 467
ERROR - 2022-11-29 17:47:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 557
ERROR - 2022-11-29 17:47:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\table_frame_reflower.cls.php 558
ERROR - 2022-11-29 17:47:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:47:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
ERROR - 2022-11-29 17:47:45 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\text_renderer.cls.php 123
ERROR - 2022-11-29 17:47:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\taker_rci3\taker_rci3\taker_dompdf\dompdf\include\style.cls.php 472
