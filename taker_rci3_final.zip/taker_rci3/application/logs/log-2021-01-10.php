<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-10 09:21:01 --> 404 Page Not Found: Atomxml/index
ERROR - 2021-01-10 19:36:20 --> 404 Page Not Found: Sitemap_indexxml/index
