<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-04 00:56:46 --> 404 Page Not Found: Robotstxt/index
