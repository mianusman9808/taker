<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-10 13:29:30 --> 404 Page Not Found: Taker/index
ERROR - 2019-07-10 17:02:27 --> 404 Page Not Found: Git/config
ERROR - 2019-07-10 17:02:27 --> 404 Page Not Found: Git/config
