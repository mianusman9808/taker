<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-12 02:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-12 15:28:44 --> 404 Page Not Found: Taker/index
