<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-01 08:08:48 --> 404 Page Not Found: Components/com_jce
ERROR - 2019-06-01 21:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-01 23:45:59 --> 404 Page Not Found: Robotstxt/index
