<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-23 00:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-23 00:36:06 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-23 10:26:56 --> 404 Page Not Found: Robotstxt/index
