<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-20 11:14:17 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2021-11-20 18:43:29 --> 404 Page Not Found: Env/index
ERROR - 2021-11-20 20:26:59 --> 404 Page Not Found: Robotstxt/index
