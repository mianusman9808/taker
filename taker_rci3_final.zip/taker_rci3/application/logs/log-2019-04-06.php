<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-06 21:20:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-06 23:03:26 --> 404 Page Not Found: Robotstxt/index
