<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-16 00:08:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-16 14:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-16 15:39:54 --> 404 Page Not Found: Robotstxt/index
