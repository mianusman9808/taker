<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-03 09:12:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-03 11:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-03 22:52:44 --> 404 Page Not Found: Robotstxt/index
