<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-11 04:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-11 09:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-11 18:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-11 20:50:13 --> 404 Page Not Found: Robotstxt/index
