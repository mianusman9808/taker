<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-18 07:25:24 --> 404 Page Not Found: Taker/index
ERROR - 2019-05-18 13:59:26 --> 404 Page Not Found: Acceso/js
ERROR - 2019-05-18 13:59:28 --> 404 Page Not Found: Acceso/js
ERROR - 2019-05-18 18:04:58 --> 404 Page Not Found: Acceso/js
ERROR - 2019-05-18 18:05:00 --> 404 Page Not Found: Acceso/js
ERROR - 2019-05-18 18:20:13 --> 404 Page Not Found: Acceso/js
ERROR - 2019-05-18 18:20:13 --> 404 Page Not Found: Acceso/js
