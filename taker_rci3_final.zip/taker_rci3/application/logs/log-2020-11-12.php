<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-12 15:45:06 --> 404 Page Not Found: Robotstxt/index
