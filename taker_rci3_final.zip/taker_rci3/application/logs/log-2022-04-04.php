<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-04 22:20:46 --> 404 Page Not Found: Robotstxt/index
