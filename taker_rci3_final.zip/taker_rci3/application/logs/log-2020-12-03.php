<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-03 01:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-03 09:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-03 21:59:22 --> 404 Page Not Found: Robotstxt/index
