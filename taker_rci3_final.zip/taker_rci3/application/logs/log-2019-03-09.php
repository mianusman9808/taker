<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-09 01:33:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-09 18:54:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-09 23:49:44 --> 404 Page Not Found: Robotstxt/index
