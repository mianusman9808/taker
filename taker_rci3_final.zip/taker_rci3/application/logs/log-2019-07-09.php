<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-09 22:55:40 --> 404 Page Not Found: Robotstxt/index
