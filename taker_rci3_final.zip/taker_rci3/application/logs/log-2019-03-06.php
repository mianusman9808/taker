<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-06 07:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-06 22:46:41 --> 404 Page Not Found: Robotstxt/index
