<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-26 17:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-10-26 20:09:40 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2020-10-26 20:09:41 --> 404 Page Not Found: Robotstxt/index
