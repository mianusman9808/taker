<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-01 01:18:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-04-01 09:16:30 --> 404 Page Not Found: _profiler/empty
