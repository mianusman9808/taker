<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-22 09:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-22 13:04:43 --> 404 Page Not Found: Robotstxt/index
