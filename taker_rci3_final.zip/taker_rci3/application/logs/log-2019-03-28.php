<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-28 04:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-28 06:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-28 13:00:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-28 13:00:16 --> 404 Page Not Found: Robotstxt/index
