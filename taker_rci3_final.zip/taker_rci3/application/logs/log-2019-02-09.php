<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-09 00:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-09 08:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-09 13:17:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-09 20:34:19 --> 404 Page Not Found: Robotstxt/index
