<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-19 08:27:43 --> 404 Page Not Found: Robotstxt/index
