<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-16 00:28:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-16 19:52:08 --> 404 Page Not Found: Faviconico/index
