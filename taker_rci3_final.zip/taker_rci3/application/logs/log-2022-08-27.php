<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-27 08:55:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-08-27 19:07:30 --> 404 Page Not Found: Wp-loginphp/index
