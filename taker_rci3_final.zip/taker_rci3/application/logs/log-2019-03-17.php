<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-17 05:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-17 22:41:45 --> 404 Page Not Found: Robotstxt/index
