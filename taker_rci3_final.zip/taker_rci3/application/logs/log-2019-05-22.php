<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-22 00:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-22 10:08:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-22 10:08:08 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:30 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:30 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:30 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:30 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:30 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:30 --> 404 Page Not Found: Taker_ap_turismo/index
ERROR - 2019-05-22 23:45:30 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:31 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:32 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:32 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:33 --> 404 Page Not Found: Taker_ap_barrios/index
ERROR - 2019-05-22 23:45:33 --> 404 Page Not Found: Taker_rci3/index
ERROR - 2019-05-22 23:45:33 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:33 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:33 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:33 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:33 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:33 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:33 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:33 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:33 --> 404 Page Not Found: Taker/assets
ERROR - 2019-05-22 23:45:35 --> 404 Page Not Found: Taker/empresa.php
ERROR - 2019-05-22 23:56:32 --> 404 Page Not Found: Robotstxt/index
