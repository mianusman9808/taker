<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-24 09:23:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-24 20:29:58 --> 404 Page Not Found: Robotstxt/index
