<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-25 07:32:20 --> 404 Page Not Found: Taker/index.php
ERROR - 2019-06-25 16:52:50 --> 404 Page Not Found: Taker/index.php
ERROR - 2019-06-25 23:36:19 --> 404 Page Not Found: Robotstxt/index
