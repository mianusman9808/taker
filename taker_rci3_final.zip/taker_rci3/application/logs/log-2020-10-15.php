<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-15 10:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-10-15 20:01:56 --> 404 Page Not Found: Taker/index
ERROR - 2020-10-15 21:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-10-15 21:49:49 --> 404 Page Not Found: Taker_ap_barrios/index
