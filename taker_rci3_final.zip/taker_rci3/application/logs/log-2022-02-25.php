<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-25 20:24:26 --> 404 Page Not Found: Robotstxt/index
