<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-01 00:22:43 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-06-01 23:04:03 --> 404 Page Not Found: Robotstxt/index
