<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-15 23:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-15 23:18:14 --> 404 Page Not Found: Robotstxt/index
