<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-12 22:36:44 --> 404 Page Not Found: Robotstxt/index
