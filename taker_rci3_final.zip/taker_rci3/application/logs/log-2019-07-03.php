<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-03 15:03:06 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2019-07-03 22:55:22 --> 404 Page Not Found: Robotstxt/index
