<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-16 16:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-16 20:09:32 --> 404 Page Not Found: Robotstxt/index
