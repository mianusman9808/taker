<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-18 12:23:32 --> 404 Page Not Found: Robotstxt/index
