<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-03 01:01:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-03 15:43:59 --> 404 Page Not Found: Robotstxt/index
