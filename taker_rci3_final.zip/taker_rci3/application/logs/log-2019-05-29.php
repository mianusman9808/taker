<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-29 16:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-05-29 16:33:18 --> 404 Page Not Found: Taker/index.php
ERROR - 2019-05-29 21:44:55 --> 404 Page Not Found: Robotstxt/index
