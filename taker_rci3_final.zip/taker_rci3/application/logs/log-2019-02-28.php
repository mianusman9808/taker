<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-28 08:26:22 --> 404 Page Not Found: Robotstxt/index
