<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-29 19:53:52 --> 404 Page Not Found: Wp-loginphp/index
