<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-30 04:38:31 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2021-12-30 05:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-30 16:08:35 --> 404 Page Not Found: Wp-loginphp/index
