<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-28 01:07:23 --> 404 Page Not Found: Taker/index
ERROR - 2019-05-28 07:59:38 --> 404 Page Not Found: Taker/index.php
