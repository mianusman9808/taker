<?php if ($FechaDesde <= '2016-09-01 00:00:00'):?>
    <p><small>
            <strong>Rep&uacute;blica Argentina: Responsabilidad Civil Obligatoria.- Res. 21.999 SSN</strong><br />
            L&iacute;mite m&aacute;ximo por todo acontecimiento: $ars 4.000.000.-<br>
            L&iacute;mite m&aacute;ximo no transportados: por evento $ars 2.000.000, por persona $ars 500.000.-<br>
            L&iacute;mite m&aacute;ximo transportados: por evento $ars 1.200.000, por persona $ars 300.000.-<br>
            L&iacute;mite m&aacute;ximo da&ntilde;os materiales a cosas de terceros: $ars 800.000.-<br>
            Reintegro por gastos de Mec&aacute;nica Ligera y/o Remolque en Rep&uacute;blica Argentina $ars1.000.- <br>
            <strong>Per&uacute;, Bolivia, Uruguay, Brasil y Paraguay:</strong><br />
            Responsabilidad civil hacia terceros no transportados por lesiones y/o muerte: L&iacute;mite por persona us$40.000 y l&iacute;mite por evento us$200.000.-<br>
            Responsabilidad civil hacia terceros no transportados por da&ntilde;os a cosas: L&iacute;mite m&aacute;ximo por persona us$20.000 y l&iacute;mite por evento us$40.000.-
    </small></p>
<?php else: ?>
    <p><small>
        <strong>Rep&uacute;blica Argentina Argentina: Responsabilidad Civil Obligatoria.- Res. 39.927 SSN</strong><br />
        Responsabilidad civil hacia terceros, l&iacute;mite m&aacute;ximo por  acontecimiento de $ars. 6.000.000.- <br />
        Incluyendo da&ntilde;os materiales a cosas de terceros no transportados y da&ntilde;os por lesiones y/o muerte a terceros transportados y no transportados.<br />
        Reintegro por gastos de Mec&aacute;nica Ligera y/o Remolque en Rep&uacute;blica Argentina $ars1.000.-<br />
        <strong>Bolivia, Uruguay, Brasil y Paraguay:</strong>
        Responsabilidad civil por muerte o da&ntilde;os personales: L&iacute;mite por persona us$40.000 y l&iacute;mite por evento us$200.000.-<br />
        Responsabilidad civil por da&ntilde;os materiales: L&Iacute;mite por tercero us$20.000 y l&iacute;mite por evento us$40.000.-<br />
    </small></p>
<?php endif ?>