<style>
  
   #newtable .hot {
        background-color:#E9E9E9;
        border:1px solid white;
        font-family: Arial, Helvetica, sans-serif;
    }
    #newtable .cool{
      background-color:#c1bfbf !important;
      border:1px solid white;
      font-family: Arial, Helvetica, sans-serif;
    }
    
</style>
<div style="position: relative; top: 0; left: 0; z-index: 1;">

<table  id="newtable" width="100%"  cellpadding="2" cellspacing="0"   class="tablaContenido">
<tr>
    <td colspan="4" class="tdContenidoItem" style="background-color:#40ce18;"><h2 style="color:white">TIPO DE COBERTURA:</h2></td>
  </tr>
  <tr>
    <td  colspan="1" class="tdContenidoItem cool">Tipo de Cobertura:</td>
    <td bgcolor="#E9E9E9" colspan="3" class="tdContenido hot">RESPONSABILIDAD CIVIL</td>
    
  </tr>
  <tr>
    <td  colspan="1" class="tdContenidoItem cool">Accidente Total:</td>
    <td bgcolor="#E9E9E9"  colspan="3" class="tdContenido hot">NO</td>
    
  </tr>
  <tr>
    <td  colspan="1" class="tdContenidoItem cool">Accidente Parcial:</td>
    <td bgcolor="#E9E9E9" colspan="3" class="tdContenido hot">NO</td>
    
  </tr>
  <tr>
    <td  colspan="1"  class="tdContenidoItem cool">Incendio Total:</td>
    <td bgcolor="#E9E9E9" colspan="3" class="tdContenido hot">NO</td>
  </tr>
  <tr>
    <td  colspan="1"  class="tdContenidoItem cool">Incendio Parcial:</td>
    <td bgcolor="#E9E9E9" colspan="3" class="tdContenido hot">NO</td>
  </tr>
  <tr>
    <td  colspan="1"  class="tdContenidoItem cool">Robo O Hurto Total:</td>
    <td bgcolor="#E9E9E9" colspan="3" class="tdContenido hot">NO</td>
  </tr>
  <tr>
    <td  colspan="1"  class="tdContenidoItem cool">Robo O Hurto Parcial:</td>
    <td bgcolor="#E9E9E9" colspan="3" class="tdContenido hot">NO</td>
  </tr>
  <tr>
    <td  colspan="1"  class="tdContenidoItem cool">Límite R. Civil:</td>
    <td bgcolor="#E9E9E9" colspan="3" class="tdContenido hot">$ 23.000.000</td>
  </tr>
  <tr>
    <td  colspan="1"  class="tdContenidoItem cool">Conductor:</td>
    <td bgcolor="#E9E9E9" colspan="3" class="tdContenido hot"><?php echo $Anio ?></td>
  </tr>
  <tr>
    <td  colspan="1"  class="tdContenidoItem cool">Monto de Franquicia:</td>
    <td bgcolor="#E9E9E9" colspan="3" class="tdContenido hot"><?php echo $Anio ?></td>
  </tr>
  <tr>
    <td  colspan="1"  class="tdContenidoItem cool">PRODUCTOR:</td>
    <td bgcolor="#E9E9E9" colspan="3" class="tdContenido hot">02139 - XXXXXX</td>
  </tr>
</table>
<div style="position: absolute; top: 0; left: 0; height: 2200px; width: 300px; z-index: 2;">
<img src="<?php echo PDF_IMAGES;?>ramiroman.png" style="margin: 0; padding: 0; height: 220px; width: 200px; padding-left:28rem; padding-top: 2rem;">
</div>
</div>