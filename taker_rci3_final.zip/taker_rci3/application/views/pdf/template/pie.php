<table width="100%"  border="0" align="center" cellpadding="2" cellspacing="2" style="margin-top: -1rem;">
  <tr>
    <td align="left"><img src="<?php echo PDF_IMAGES;?>ramirobluecar.png" width="250" height="120"></td>
    <td align="right"><img src="<?php echo PDF_IMAGES;?>signature.png" width="94" height="100"></td>
  </tr>
  <tr>
    <!-- <td>Lugar y fecha de emisi&oacuten de la p&oacuteliza: Mendoza , <?php echo $Fecha ?></td> -->
    
    <td colspan="2" align="right" style="padding-right: 2rem;"><strong>Juan Perrin 
</strong></td>
  </tr>
  <tr>
  <td colspan="2" align="right"><strong>FIRMA AUTORIZADA 
</strong></td>
  </tr>
</table>
<!-- <div id="letraChica" align="center">
<p><small>Necochea N&deg;183 M5500GLC Capital Mendoza Tel. 54261-4298388 Fax. 54261-4255998<br>
  Av. Madero N&deg;942 Piso 18 C1106ACW Capital Federal Buenos Aires Tel. 5411-43105400 Fax. 5411-43152470</small></p>
</div> -->