  <!-- <tr>
    <td align="right" style="width:10em" class="tdContenidoItem"><strong></strong></td>
    <td bgcolor="#E9E9E9"  style="width:12.5em"class="tdContenido" align="center"><strong></strong></td>
    <td align="right" style="width:10em" class="tdContenidoItem"><strong>Medio de pago:</strong></td>
    <td bgcolor="#E9E9E9" class="tdContenido" align="center"><strong><?php echo $MedioPago ?></strong></td>
  </tr>
   -->