<!-- <div align="right"><img width="174" height="40" src="<?php echo PDF_IMAGES;?>mercantilLogo.jpg" /></div> -->

<div style="width:100%; height:1rem; background-color:#40ce18;"></div>
<br>
<table style="margin-top: -1rem; ">
    <tr>
        <th style="padding-left:1em" colspan="4">
        <h2 style="margin-top: -1rem;font-family: ff2;line-height: 1.207031;font-style: normal;font-weight: normal;visibility: visible;">Certificado de Cobertura</h2>
        </th>
        <th style="padding-left:12em">
        <div style="width:100%"><img width="174" height="40" src="<?php echo PDF_IMAGES;?>ramirologo.png" style="align:right" /></div>
        </th>
    </tr>

</table>
<div style="width:100%; height:0.2rem; background-color:#40ce18;"></div>
<table style="background-color: #E9E9E9; width:100%;">
<tr>
           
           <td style="padding-left: 1em;padding-top:2em">
               <img width="250" height="150" src="<?php echo PDF_IMAGES;?>carramiro.png" style="margin-top: -4rem;" alt="">
           </td>
           <td style="padding-left: 6rem; padding-bottom: 1rem;">
               <table>
                   <tr>
                       <td>
                           <h3 style="padding-left:2rem; font-family: Arial, Helvetica, sans-serif;">Fecha:</h3>
                       </td>
                       <td>
                           <span style="background-color: yellow; font-family: Arial, Helvetica, sans-serif;"><?php echo $desdeDias ?><span> </span><?php echo $desdeHoras ?></span>
                       </td>
                   </tr>
                   <tr>
                       <td>
                           <h3 style=" font-family: Arial, Helvetica, sans-serif;">Vencimiento:</h3>
               
                       </td>
                       <td>
                           <p style="background-color: yellow; font-family: Arial, Helvetica, sans-serif;"><?php echo $FechaHasta ?><span> </span> <?php echo $hastaHoras ?>
                               N° 8023090</p>
                       </td>
                   </tr>
               
               
               </table>
           </td>
          
       </tr>
</table>