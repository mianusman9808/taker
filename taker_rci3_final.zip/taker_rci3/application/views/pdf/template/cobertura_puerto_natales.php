<?php if ($FechaDesde <= '2016-09-01 00:00:00'):?>
    <p><small>
            <strong>Rep&uacute;blica Argentina: Responsabilidad Civil Obligatoria.- Res. 21.999 SSN</strong><br>
            <strong>Rep&uacute;blicas de  Argentina:</strong><br>
            L&iacute;mite m&aacute;ximo por todo acontecimiento: $ars 4.000.000.-<br>
            L&iacute;mite m&aacute;ximo no transportados: por evento $ars 2.000.000, por persona $ars 500.000.-<br>
            L&iacute;mite m&aacute;ximo transportados: por evento $ars 1.200.000,por persona $ars 300.000.-<br>
            L&iacute;mite m&aacute;ximo da&ntilde;os materiales a cosas de terceros: $ars 800.000.-
    </small></p>
<?php else: ?>
    <p><small>
        <strong>Rep&uacute;blica Argentina: Responsabilidad Civil Obligatoria.- Res. 39.927 SSN</strong><br />
        Responsabilidad civil hacia terceros, l&iacute;mite m&aacute;ximo por  acontecimiento de $ars. 6.000.000.- <br />
        Incluyendo da&ntilde;os materiales a cosas de terceros no transportados y da&ntilde;os por lesiones y/o muerte a terceros transportados y no transportados.
    </small></p>
<?php endif ?>
