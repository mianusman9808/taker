<?php if (!isset($otros_paises)){
    $otros_paises=true;
}

?>
 
<table width="100%" border="0" cellpadding="2" cellspacing="0" bordercolor="#999999"  class="tablaContenido">
<tr>
<td class="tdContenidoItem">  
             <br>
<h3 style="margin-top: -0.7rem;">ADVERTENCIAS AL ASEGURADO:</h3>
<!-- <strong>Mendoza Capital 0261-4298388</strong><br> -->
<p style="font-family: ff2;
    line-height: 1;
    font-style: normal;
    font-weight: normal;
    visibility: visible;
    font-size: 0.9em;">
El presente es un instrumento provisorio. Dentro de los QUINCE (15) días corridos, contados a partir de su fecha de emisión, deberá requerirse la entrega de la póliza respectiva. La cobertura prevista en el presente certificado está sujeta a la inspección vehicular por parte de la compañía. Hasta tanto se efectué tal Inspección, la compañía se limitará a otorgar la cobertura correspondiente al seguro obligatorio del automotor conforme decreto Nº 1716/08, reglamentada por resolución SSN Nº 34.225. Esta condición no es aplicable a unidades 0KM.
<br>
El vehículo cuyos datos se detallan en el presente certificado, se encuentra amparado en el riesgo de responsabilidad civil por daños causados a personas o cosas no transportadas, conforme con los montos y condiciones establecidas en la resolución del grupo Mercado Común a los países integrantes del Mercosur. Esta cobertura comprende los países de Brasil, Paraguay y Uruguay.<br>
De acuerdo con lo establecido en las condiciones particulares de la póliza (Cláusula CO-EX9.1), se extiende la cobertura de responsabilidad civil por daños sufridos por terceros no transportados en el vehículo asegurado a los países de Chile y Bolivia con un límite de U$S 300.000.- (dólares estadounidenses doscientos mil) para muerte, gastos médicos-hospitalarios y/o daños personales y un límite de U$S 40.000.- (dólares estadounidenses cuarenta mil) para daños materiales.<br>
Los asegurados podrán solicitar información ante la Superintendencia de Seguros de la Nación con relación a la entidad aseguradora, dirigiéndose personalmente o por nota a Julio A. Roca 721(C.P. 1067), Ciudad de Buenos Aires; por teléfono al 4338-4000 (líneas rotativas), en el horario de 10:30 a 17:30; o vía internet a la siguiente dirección: www.ssn.gov.ar.<br>
El presente certificado se suscribe con firma facsimilar conforme lo dispuesto en el punto 7.9 del reglamento general de la actividad aseguradora.
</p>



                
<?php if($otros_paises):?>
    <!-- <strong>Representantes de Mercantil Andina en otros pa&iacute;ses:</strong><br>
    Brasil: HDI Seguros S.A. Av. Marechal Floriano Peixoto 4935 Vila Hauer Cep: 81.610-000 
    Curitiba PR Tel. (5541)32199100 0800-7015430 08007077724 Paraguay: El Comercio Paraguayo S.A. 
    Cia. de Seguros Generales Alberdi 453 Asunci&oacute;n Tel. (00595)21492324/25 Uruguay: 
    Banco de Seguros del Estado de la Rep&uacute;blica Oriental del Uruguay Bv. Artigas 3821 Montevideo 
    Tel. (005982)233773 Bolivia: Compa&ntilde;&iacute;a de Seguros Illimani S.A. Loayza N 233 La Paz Bolivia 
    Tel. (00591-2)2203040    -->
    
<?php endif ?>

</small></p>

</td>
</tr>
</table>