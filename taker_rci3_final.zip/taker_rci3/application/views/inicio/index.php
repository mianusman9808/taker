<?php $this->load->view('template/header');?>

<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3 ">
            
            <img src="<?php echo base_url()?>banners/boston_camiones.jpg" class="img-responsive" />
        </div><!-- col -->
        <div class="col-md-2">
            <div class="well" style="margin-top: 50px">
                
                <a href="<?php echo base_url()?>certificado" class="btn btn-primary btn-lg">Ingresar al sistema</a>
            </div>
        </div>
    </div><!-- row -->
</div><!-- container -->

<?php $this->load->view('template/footer');?>