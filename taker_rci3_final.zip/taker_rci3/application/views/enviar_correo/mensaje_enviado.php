<?php $this->load->view('template/header'); ?>

<div class="container">
<div class="row">
<div class="col-md-12">
    
	<h2 id="page-heading">Enviar correo</h2>

	<p>El mensaje se ha enviado con éxito.</p>
	
</div><!-- col-12 -->
</div><!-- row -->
</div><!-- container -->

<?php $this->load->view('template/footer'); ?>
