<?php $this->load->view('template/header'); ?>

<div class="container">
<div class="row">
<div class="col-md-12">
	
	<h2>Enviar correo</h2>

	<p class="alert alert-danger">ERROR. No se ha podido enviar el correo.</p>
	
</div><!-- col-12 -->
</div><!-- row -->
</div><!-- container -->
<?php $this->load->view('template/footer'); ?>
