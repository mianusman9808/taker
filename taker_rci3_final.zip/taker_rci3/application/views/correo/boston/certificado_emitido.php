<h2>TAKER RCI</h2>
<h3>Boston</h3>		

<p>Número Certificado: <?php echo $certificado['Numero']; ?></p>
<p>Conductor: <?php echo $certificado['conductor']; ?></p>
<p>Asegurado: <?php echo $certificado['Nombre']; ?></p>
<p>Documento Número: <?php echo $certificado['Rut']; ?></p>
<p>Domicilio: <?php echo $certificado['Domicilio']; ?></p>
<p>Localidad: <?php echo $certificado['Localidad']; ?></p>
<p>País: <?php echo $certificado['Pais']; ?></p>
<p>Vigencia Desde las <?php echo $desdeHoras; ?> del <?php echo $desdeDias; ?></p>
<p>Vigencia Hasta: <?php echo $certificado['FechaHasta']; ?></p>

<p>Producto: <b><?php echo $producto['nombre']; ?></b></p>

<p>Motor: <?php echo $certificado['Motor']; ?></p>
<p>Marca: <?php echo $certificado['Marca']; ?></p>
<p>Chasis: <?php echo $certificado['Chasis']; ?></p>
<p>Modelo: <?php echo $certificado['Modelo']; ?></p>
<p>Uso: <?php echo $certificado['Uso']; ?></p>
<p>Año: <?php echo $certificado['Anio']; ?></p>
<p>Patente: <?php echo $certificado['Patente']; ?></p>
<p>Digito: <?php echo $certificado['digito']; ?></p>

