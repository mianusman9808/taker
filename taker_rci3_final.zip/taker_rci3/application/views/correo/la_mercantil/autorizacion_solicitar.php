<p>Señores Mercantil andina, solicito por medio del presente autorización de modelo del siguiente vehículo:</p> 
<p></p>
<p>Año: <?php echo $certificado['Anio']; ?></p>
<p>Patente: <?php echo $certificado['Patente']; ?></p>
<p>Digito: <?php echo $certificado['digito']; ?></p>
<p>Marca: <?php echo $certificado['Marca']; ?></p>
<p>Modelo: <?php echo $certificado['Modelo']; ?></p>
<p></p>
<p>Quedamos al aguardo de la autorización.</p>
<p>Muchas gracias.</p>
<p>Saludos cordiales.</p>
<?php echo $usuario['Nombre']; ?>