<?php

include_once("../taker/inc/header.php");
$item = $productos[0];
$formulario=APPPATH."views/acceso/formulario.php";
include_once('../taker/inc/template.php');
include_once("../taker/inc/footer.php");

?>
