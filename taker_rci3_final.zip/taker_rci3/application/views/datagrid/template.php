<?php $this->load->view("template/header"); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12" id="datagrid">
            <?php echo $datagrid;?>
        </div>
     </div>
</div>

<?php $this->load->view("template/footer"); ?>