<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="datos_footer">
                  <p><img src="<?php echo base_url();?>assets/css/img/footer-marca-taker.png"> </p>
                  <p>Copyright 2008. Todos los derechos reservados<br>
                    Monseñor Zabalza 33, Ciudad. CP 5500. Mendoza - Argentina<br>
                    Tel/fax: +54 261 4253790
                    // +54 261 4250215<br>
                    Correo Electrónico: <a href="mailto:info@taker.com.ar">info@taker.com.ar</a><br>
            
                  </p>
             </div>
        </div>  
    </div> 
</div>


</body>
</html>
<?php
//echo "Probability: ".ini_get("session.gc_probability");
//echo " Divisor: ". ini_get("session.gc_divisor");
//echo " Maxlifetime: ".ini_get("session.gc_maxlifetime");