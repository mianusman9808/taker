<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['dt_add'] = "Agregar";
$lang['dt_edit'] = "Modificar";
$lang['dt_delete'] = "Borrar";
$lang['dt_view'] = "Ver";
$lang['dt_search'] = "Buscar";
$lang['dt_cancel'] = "Cancelar";
$lang['dt_return'] = "Volver";
$lang['dt_no_result'] = "No se encontraron datos";
$lang['dt_total_rows'] = "Total de registros";
$lang['dt_total_sum'] = "Sumatoria";
$lang['dt_export_excel'] = "Exportar Excel";
$lang['dt_requerido'] = "datos requeridos obligatorios";
