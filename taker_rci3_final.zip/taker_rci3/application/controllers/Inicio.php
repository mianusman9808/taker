<?php 
class inicio extends MY_Controller
{
	function index()
	{
        $this->load->view('inicio/index');
    }
	

    
}
///FIN