<?php
//header("Location: /fuera_de_servicio.html");
//exit;

//HORA
date_default_timezone_set('America/Buenos_Aires');
setlocale(LC_ALL,"es_AR.UTF8");
setlocale(LC_NUMERIC ,"en_US.UTF-8");

//Garbage Cleaner de la session
//Probabilidad 1 en 1000
//ini_set('session.gc_probability',1);
//ini_set('session.gc_divisor',1000);

///VARIABLES GLOBALES
define('NOMBRESITIO', 'Taker RCI');
define('METAKEYWORDS', 'Taker RCI');
define('METADESCRIPCION', 'Taker RCI');
define('LANGUAGE','spanish');
define('INDEX_PAGE','');

//LA MERCANTIL  
define('VEHICULO_ANIO_MINIMO_APROBADO','25');   //HASTA 25 años se puede asegurar sin solicitar                                             //autorizacion 
define('VEHICULO_ANIO_MINIMO','40');    //40 AÑOS MENOS QUE EL AÑO MAXIMO
define('VEHICULO_ANIO_MAXIMO','1');     //1 AÑO MAS QUE EL AÑO ACTUAL

//BOSTON
//Boston no envia correo para solicitar si es aprobado (VEHICULO_ANIO_MINIMO_APROBADO)
define('BOSTON_VEHICULO_ANIO_MINIMO','30');    //30 AÑOS MENOS QUE EL AÑO MAXIMO
define('BOSTON_VEHICULO_ANIO_MAXIMO','1');     //1 AÑO MAS QUE EL AÑO ACTUAL

//CODIGO
define('DIAS_VALIDEZ_CODIGO','120');

//CUENTAS DE CORREO
define('MAIL_ADMIN',    'info@taker.com.ar');
define("FROM_NAME",     "Taker");
define("FROM_CORREO",   "info@taker.com.ar");



//define("JMYA_CORREO_1","slinares@jmya.com.ar");


//define("MERCANTIL_CORREO_1","bellidot@lamercantil.com.ar");
//define("MERCANTIL_CORREO_2","debernar@lamercantil.com.ar");
//define("MERCANTIL_CORREO_1","veronica.ochoa@lamercantil.com.ar");
//define("MERCANTIL_CORREO_2","javier.balmaceda@lamercantil.com.ar");
define("MERCANTIL_CORREO_1","omar.abdala@lamercantil.com.ar");

//CORREO AUTORIZACION VEHICULOS VIEJOS
define("MERCANTIL_CORREO_AUTORIZACION","leonardo.bettiol@lamercantil.com.ar");


//SESSION
define('SESSION_NAME','rci3');

//Máximo sobreprecio permitdo en dolares 
//Sobre el costo del producto. Solo lo pueden hacer los vendedores con capacidad de fijar precios
define('SOBREPRECIO',10);


if($_SERVER['SERVER_NAME']=="localhost") {

    //URLS
    define('BASEURL',           'http://localhost/taker_rci3/taker_rci3/');
    define('FRONTURL',          'http://localhost/taker_rci3/taker_rci3/');
    define('URI_PROTOCOL',      "AUTO");

    //PATHS
    define('CAPTCHAPATH',   'C:/xampp/htdocs/taker_rci3/taker_rci3/captcha/');
    define('CACHEPATH',     'C:/xampp/htdocs/taker_rci3/taker_rci3/cache/');
    define('DOMPDFPATH',    'taker_dompdf/');
    define('PDF_IMAGES',    'C:/xampp/htdocs/taker_rci3/taker_rci3/images/');
    
    //BASE DE DATOS
    define('DATABASE_HOST',    'localhost');
    define('DATABASE',         'taker_rci3');
    define('DATABASE_USER',    'root');
    define('DATABASE_PASS',    '');
    define('DATABASE_DEBUG',   true);
    //WS
    define('WSDL_MERCANTIL'        ,'https://gestionpas.mercantilandina.com.ar/ws_nuevoSeguroChileTST/NuevoSeguroChileServices/NuevoSeguroChileServices.wsdl');

    //define('WSDL_MERCANTIL_PRIMA'  ,'55.47');
    //define('WSDL_MERCANTIL_PREMIO' ,'101.00');
    define('WSDL_MERCANTIL_CANAL'  ,'18');
    define('WSDL_MERCANTIL_TOKEN'  ,'');
     
     
     
    //PATHS CODEIGNITER
    $system_path =          'C:/xampp/htdocs/taker_rci3/taker_rci3/system';
    $application_folder =   'C:/xampp/htdocs/taker_rci3/taker_rci3/application';
    $view_folder =          'C:/xampp/htdocs/taker_rci3/taker_rci3/application/views';
    
    define('ENVIRONMENT',   'development');
    
    //ERRORES
    //error_reporting(E_ALL);
    //ini_set('display_errors', true);
    
}else{
    //PRODUCCION

    $path=  "/var/www/www.taker.com.ar/html/taker_rci3/";
    //TODO: Usar url absoluta luego de migrar
    //$url=   "https://www.taker.com.ar/taker_rci3/";
    $url=   "/taker_rci3/";

    //PATHS
    define('CAPTCHADPATH',  $path.'captcha/');
    define('CACHEPATH',     $path.'cache/');
    define('DOMPDFPATH',    '/var/www/www.taker.com.ar/html/taker_dompdf/');
    define('PDF_IMAGES',    $path.'images/');    
    
    //URL
    define('BASEURL',       $url);
    define('FRONTURL',      $url);
    define('URI_PROTOCOL',      "AUTO");
    
    //BASE DE DATOS
    define('DATABASE_HOST',  'localhost');
    define('DATABASE',       'taker_jmya_rci2');
    define('DATABASE_USER',  'taker_user');
    define('DATABASE_PASS',  '');
    define('DATABASE_DEBUG',  true);

    //WS
    define('WSDL_MERCANTIL'        ,'https://gestionpas.mercantilandina.com.ar/ws_nuevoSeguroChilePRD/NuevoSeguroChileServices/wsdl');
    //define('WSDL_MERCANTIL_PRIMA'  ,'55.47');
    //define('WSDL_MERCANTIL_PREMIO' ,'101.00');
    define('WSDL_MERCANTIL_CANAL'  ,'18');
    define('WSDL_MERCANTIL_TOKEN'  ,'');
        
    //PATHS CODEIGNITER
    $system_path =          $path."system";
    $application_folder =   $path.'application';
    $view_folder =          $path.'application/views';
    
    define('ENVIRONMENT',   'production');
    
    //ERRORES
    //TODO: false luego de migrar
    error_reporting(E_ALL);
    ini_set('display_errors', true);
}



define('SELF', pathinfo(__FILE__, PATHINFO_BASENAME));
define('BASEPATH', $system_path.DIRECTORY_SEPARATOR);
define('FCPATH', dirname(__FILE__).DIRECTORY_SEPARATOR);
define('SYSDIR', basename(BASEPATH));
define('APPPATH', $application_folder.DIRECTORY_SEPARATOR);
define('VIEWPATH', $view_folder.DIRECTORY_SEPARATOR);

require_once APPPATH.'soap/WSASoap.php';
class MyClient extends \SoapClient
{
    public function __doRequest($request, $location, $saction, $version, $one_way = 0)
    {
        //echo $request;
        //exit;
        $dom = new DOMDocument();
        $dom->loadXML($request);
        //echo $saction;
        //exit;
        $wsa = new WS\WSASoap($dom);
        $wsa->addAction($saction);
        $wsa->addTo($location);
        $wsa->addMessageID();
        $wsa->addReplyTo();

        $request = $wsa->saveXML();

        return parent::__doRequest($request, $location, $saction, $version);
    }

}

require_once BASEPATH.'core/CodeIgniter.php';
