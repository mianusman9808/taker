<?php
var_dump(openssl_get_cert_locations());
?>

